param([Parameter(Mandatory=$true)][string]$PackagePath)
$ErrorActionPreference='Stop'
$package=(Resolve-Path -LiteralPath $PackagePath).Path
if(-not (Test-Path -LiteralPath (Join-Path $package 'components\baseline\core.sha256'))) { throw 'Use a complete transparent-output package with its verified baseline.' }
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$common=@('/nologo','/target:winexe','/optimize+','/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll','/reference:System.Web.Extensions.dll')
$sources=@('LauncherV711.cs','AssistantBridge.cs','UpdateManager.cs','QueueStore.cs','QueueComposer.cs','ProcessJob.cs','FailureLogs.cs','LifetimeJob.cs','OutputManager.cs','TemplateRecovery.cs') | ForEach-Object {Join-Path $PSScriptRoot $_}
& $compiler @common /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll ('/win32icon:'+(Join-Path $PSScriptRoot 'app.ico')) ('/out:'+(Join-Path $package '美丽武器V8.1.7.exe')) @sources
if($LASTEXITCODE -ne 0){throw 'Launcher build failed. Close this package before rebuilding.'}
& $compiler @common /unsafe /platform:x64 ('/win32icon:'+(Join-Path $PSScriptRoot 'output.ico')) ('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')) ('/out:'+(Join-Path $package 'components\Meili_Live_Alpha.exe')) (Join-Path $PSScriptRoot 'MeiliLiveAlpha.cs') (Join-Path $PSScriptRoot 'DesktopGuide.cs')
if($LASTEXITCODE -ne 0){throw 'Alpha component build failed.'}
$wrap=Join-Path $package 'components\runtime\ffwrap'
if(-not(Test-Path -LiteralPath (Join-Path $wrap 'ffprobe.original.exe'))){Copy-Item -LiteralPath (Join-Path $wrap 'ffprobe.exe') -Destination (Join-Path $wrap 'ffprobe.original.exe')}
& $compiler @common ('/out:'+(Join-Path $wrap 'ffmpeg.exe')) (Join-Path $PSScriptRoot 'RevealFFmpeg.cs')
if($LASTEXITCODE -ne 0){throw 'FFmpeg wrapper build failed.'}
& $compiler @common ('/out:'+(Join-Path $wrap 'ffprobe.exe')) (Join-Path $PSScriptRoot 'SilentProbe.cs')
if($LASTEXITCODE -ne 0){throw 'FFprobe wrapper build failed.'}
$baseline=Join-Path $PSScriptRoot 'v680-baseline.js'
$body=[IO.File]::ReadAllText($baseline,[Text.Encoding]::UTF8)
$body=$body.Replace('const finish=async completed=>{if(!playing||playing.id!==task.id)return;', 'const finish=async completed=>{if(!playing||playing.id!==task.id)return;window.bwQueueStop=null;')
$body=$body.Replace('};pv.onended=()=>finish(true);pv.onerror=()=>finish(false);await pv.play();','};window.bwQueueStop=()=>finish(false);pv.onended=()=>finish(true);pv.onerror=()=>finish(false);await pv.play();')
$body=$body.Replace('桌面“美丽武器_读取失败日志”','本软件目录内的读取失败日志')
$body += "`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'alpha-output.js'),[Text.Encoding]::UTF8)
$body += "`n"+[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'v817-ui.js'),[Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $package 'components\runtime\v680.js'),$body,[Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'harness.js') -Destination (Join-Path $package 'components\runtime\alpha\harness.js') -Force
Write-Output 'Transparent-output release rebuilt. Its launcher prepares the private core path on startup.'
