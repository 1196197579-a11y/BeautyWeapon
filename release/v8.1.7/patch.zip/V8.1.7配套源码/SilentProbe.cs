﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
class SilentProbe {
 static string Quote(string s) { return "\""+Regex.Replace(Regex.Replace(s,@"(\\*)""", "$1$1\\\""),@"(\\+)$","$1$1")+"\""; }
 static string Direction(string path) {
  if(!File.Exists(path)) return "";
  using(var f=File.OpenRead(path)) { var b=new byte[(int)Math.Min(64,f.Length)]; f.Seek(-b.Length,SeekOrigin.End); f.Read(b,0,b.Length); var s=Encoding.ASCII.GetString(b); if(s.Contains("BW_REVEAL_V1:left"))return "left"; if(s.Contains("BW_REVEAL_V1:right"))return "right"; }
  return "";
 }
 static int Main(string[] args) {
  try {
   string original=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ffprobe.original.exe");
   var quoted=new string[args.Length]; for(int i=0;i<args.Length;i++)quoted[i]=Quote(args[i]);
   var start=new ProcessStartInfo(original,string.Join(" ",quoted));
   start.UseShellExecute=false; start.CreateNoWindow=true; start.WindowStyle=ProcessWindowStyle.Hidden; start.RedirectStandardOutput=true; start.RedirectStandardError=true;
   using(var p=Process.Start(start)) {
    var output=p.StandardOutput.BaseStream.CopyToAsync(Console.OpenStandardOutput());
    var error=p.StandardError.BaseStream.CopyToAsync(Console.OpenStandardError());
    p.WaitForExit(); Task.WaitAll(output,error); return p.ExitCode;
   }
  } catch(Exception e) { Console.Error.WriteLine("Video probe: "+e.Message); return 1; }
 }
}
