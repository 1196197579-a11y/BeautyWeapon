using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
internal sealed class DesktopGuide:IDisposable {
 [StructLayout(LayoutKind.Sequential)]internal struct Rect{public int Left,Top,Right,Bottom;}
 [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr h,out Rect r);
 [DllImport("user32.dll")]static extern bool SetWindowDisplayAffinity(IntPtr h,uint value);
 [DllImport("user32.dll")]static extern bool GetWindowDisplayAffinity(IntPtr h,out uint value);
 readonly IntPtr output;readonly EdgeStrip[] edges=new EdgeStrip[4];internal bool Excluded,Visible;internal string Error="";
 internal DesktopGuide(IntPtr hwnd){output=hwnd;Excluded=true;for(int i=0;i<4;i++){edges[i]=new EdgeStrip(this,i<2);uint affinity=0;bool ok=false;try{ok=SetWindowDisplayAffinity(edges[i].Handle,0x11)&&GetWindowDisplayAffinity(edges[i].Handle,out affinity)&&affinity==0x11;}catch(EntryPointNotFoundException){}if(!ok)Excluded=false;}if(!Excluded)Error="系统未确认辅助框采集排除，已隐藏辅助框";Show(true);}
 internal void Show(bool show){Visible=show&&Excluded;Update();foreach(var edge in edges){if(Visible)edge.Show();else edge.Hide();}}
 internal void Update(){Rect r;if(!GetWindowRect(output,out r))return;int t=8,w=r.Right-r.Left,h=r.Bottom-r.Top;edges[0].Bounds=new Rectangle(r.Left,r.Top,w,t);edges[1].Bounds=new Rectangle(r.Left,r.Bottom-t,w,t);edges[2].Bounds=new Rectangle(r.Left,r.Top+t,t,Math.Max(1,h-2*t));edges[3].Bounds=new Rectangle(r.Right-t,r.Top+t,t,Math.Max(1,h-2*t));}
 internal void Move(Point delta){Rect r;GetWindowRect(output,out r);Win.SetWindowPos(output,IntPtr.Zero,r.Left+delta.X,r.Top+delta.Y,0,0,0x0015);Update();}
 public void Dispose(){foreach(var e in edges)e.Dispose();}
 sealed class EdgeStrip:Form {
  readonly DesktopGuide guide;readonly bool horizontal;Point previous;bool dragging;
  internal EdgeStrip(DesktopGuide g,bool horizontal){guide=g;this.horizontal=horizontal;FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;BackColor=Color.Fuchsia;TransparencyKey=Color.Fuchsia;Cursor=Cursors.SizeAll;Text="Meili desktop guide";SetStyle(ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint,true);}
  protected override CreateParams CreateParams{get{var p=base.CreateParams;p.ExStyle|=0x80|0x08000000;return p;}}
  protected override bool ShowWithoutActivation{get{return true;}}
  protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var shadow=new Pen(Color.Black,4))using(var line=new Pen(Color.FromArgb(65,235,205),2)){shadow.DashStyle=line.DashStyle=DashStyle.Dash;if(horizontal){e.Graphics.DrawLine(shadow,0,Height/2,Width,Height/2);e.Graphics.DrawLine(line,0,Height/2,Width,Height/2);}else{e.Graphics.DrawLine(shadow,Width/2,0,Width/2,Height);e.Graphics.DrawLine(line,Width/2,0,Width/2,Height);}}}
  protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button==MouseButtons.Left){dragging=true;previous=MousePosition;Capture=true;}}
  protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);if(dragging){Point now=MousePosition;guide.Move(new Point(now.X-previous.X,now.Y-previous.Y));previous=now;}}
  protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);dragging=false;Capture=false;}
 }
}
