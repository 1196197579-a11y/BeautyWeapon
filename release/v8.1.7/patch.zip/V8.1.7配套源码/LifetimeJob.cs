using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
internal sealed class LifetimeJob:IDisposable {
 [StructLayout(LayoutKind.Sequential)] struct Basic {public long PerProcess,PerJob;public uint Flags;public UIntPtr Min,Max;public uint Active;public UIntPtr Affinity;public uint Priority,Scheduling;}
 [StructLayout(LayoutKind.Sequential)] struct Io {public ulong Read,Write,Other,ReadBytes,WriteBytes,OtherBytes;}
 [StructLayout(LayoutKind.Sequential)] struct Limits {public Basic Basic;public Io Io;public UIntPtr ProcessMemory,JobMemory,PeakProcess,PeakJob;}
 [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr security,string name);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr job,int cls,ref Limits limits,int size);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool IsProcessInJob(IntPtr process,IntPtr job,out bool member);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
 IntPtr handle;
 internal LifetimeJob(){handle=CreateJobObject(IntPtr.Zero,null);var l=new Limits();l.Basic.Flags=0x2000;if(handle==IntPtr.Zero||!SetInformationJobObject(handle,9,ref l,Marshal.SizeOf(l)))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}
 internal void Attach(Process p){bool member;if(IsProcessInJob(p.Handle,handle,out member)&&member)return;if(!AssignProcessToJobObject(handle,p.Handle))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}
 public void Dispose(){if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;}}
}
