/* V8.1.7 transparent-output release. No colour key. Ordinary video stays opaque. */
(()=>{
 'use strict';
 if(window.BW_QUEUE_WORKER)return;
 const endpoint='http://127.0.0.1:38656',original={open:openNativeOutput,control:sendNativeControl,frame:scheduleNativeFrame,socket:connectNativeFrameSocket};
 const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;
 const ctx=canvas.getContext('2d',{alpha:true,willReadFrequently:true});let visible=false,alpha=true,opening=null,modeEpoch=0,lastError='',unloading=false,userOpened=false;
 const connected=()=>state.nativeOutputActive&&state.nativeWS?.readyState===WebSocket.OPEN;
 const encoder=new TextEncoder();
 function blank(){if(!alpha)return;visible=false;sendNativeControl();}
 function control(){if(!state.nativeOutputActive||state.nativeWS?.readyState!==WebSocket.OPEN)return;const b=encoder.encode(JSON.stringify({currentMs:(pv.currentTime||0)*1000,playing:!pv.paused&&!pv.ended,profileEnabled:false,decoEnabled:false,clockSeq:state.nativeClockSeq,alphaMode:visible?'video':'idle'}));state.nativeWS.send(new Blob([new Uint8Array([179]),b]));}
 function frame(force=false){if(!state.nativeOutputActive||state.nativeWS?.readyState!==WebSocket.OPEN||state.nativeCaptureBusy)return;if(!visible){control();return;}if(state.nativeWS.bufferedAmount>4194304&&!force)return;state.nativeCaptureBusy=true;const socket=state.nativeWS;(()=>{try{if(!visible||!alpha||socket!==state.nativeWS||socket.readyState!==WebSocket.OPEN){if(alpha)control();return;}if(pv.readyState<2||!pv.videoWidth)return;ctx.clearRect(0,0,1920,1080);ctx.fillStyle='#000';ctx.fillRect(0,0,1920,1080);coverDraw(ctx,pv,0,0,1920,1080);const im=ctx.getImageData(0,0,1920,1080);socket.send(im.data.buffer);control();}catch(e){visible=false;try{control();socket.close();}catch(_){}state.nativeOutputActive=false;toast('透明输出中断：'+e.message);}finally{state.nativeCaptureBusy=false;}})();}
 function open(notify=true){
  if(!alpha||unloading||!userOpened)return Promise.resolve(false);
  if(connected())return Promise.resolve(true);
  if(opening)return opening;
  const epoch=modeEpoch;lastError='';
  const attempt=(async()=>{try{
   const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),3000);let d;
   try{const r=await fetch(endpoint+'/open',{cache:'no-store',signal:abort.signal});d=await r.json();}finally{clearTimeout(timer);}
   if(!d.ok)throw Error(d.error||'组件未就绪');if(!alpha||unloading||epoch!==modeEpoch)return false;
   const w=await socket('ws://127.0.0.1:38656/frame');
   if(!alpha||unloading||epoch!==modeEpoch){w.close();return false;}
   state.nativeOutputActive=true;visible=!pv.paused&&!pv.ended;control();startNativeFramePump();frame(true);
   if(notify)toast('透明直播输出已连接；闲置时透明');return true;
  }catch(e){if(epoch===modeEpoch){state.nativeOutputActive=false;lastError=e.message;if(notify)toast('透明输出未连接：'+e.message+'；请点击打开直播输出窗口重试');}return false;}})();
  opening=attempt;attempt.finally(()=>{if(opening===attempt)opening=null;});return attempt;
 }
 function socket(url){return new Promise((resolve,reject)=>{if(state.nativeWS?.readyState===WebSocket.OPEN){resolve(state.nativeWS);return;}const w=new WebSocket(url);let opened=false;w.binaryType='arraybuffer';state.nativeWS=w;const timer=setTimeout(()=>{w.close();reject(Error('帧通道超时'));},3000);w.onopen=()=>{opened=true;clearTimeout(timer);resolve(w);};w.onerror=()=>{clearTimeout(timer);reject(Error('帧通道连接失败'));};w.onclose=()=>{clearTimeout(timer);if(!opened)reject(Error('帧通道已关闭'));if(state.nativeWS===w){state.nativeWS=null;state.nativeOutputActive=false;stopNativeFramePump();}};});}
 function bind(){openNativeOutput=alpha?open:original.open;sendNativeControl=alpha?control:original.control;scheduleNativeFrame=alpha?frame:original.frame;connectNativeFrameSocket=alpha?socket:original.socket;$('#openOutputBtn').onclick=toggleOutput;if($('#bw71LiveOutput'))$('#bw71LiveOutput').onclick=toggleOutput;}
 bind();
 
 pv.addEventListener('play',async()=>{if(!alpha)return;if(!userOpened)return;visible=true;if(!connected()&&!await open(false))return;if(!alpha||pv.paused||pv.ended)return;control();startNativeFramePump();frame(true);});
 for(const name of ['ended','emptied','error'])pv.addEventListener(name,blank);
 pv.addEventListener('pause',()=>{if(alpha&&visible){control();frame(true);}});
 window.addEventListener('beforeunload',()=>{blank();unloading=true;modeEpoch++;try{if(alpha)state.nativeWS?.close();}catch(_){}});
 setInterval(()=>{if(alpha)control();},500);
 async function stopPlayback(){blank();if(window.bwQueueStop)await window.bwQueueStop();else{pv.pause();if(state.playingComposed)restoreOriginal();}blank();}
 function makeStop(id){const b=document.createElement('button');b.id=id;b.className='secondary';b.textContent='停止播放';b.title='结束当前播放；透明输出模式下立即恢复透明，队列任务仍可重播';b.onclick=()=>stopPlayback().catch(e=>toast('停止失败：'+e.message));return b;}
 function makeStatus(id){const e=document.createElement('div');e.id=id;e.setAttribute('aria-live','polite');e.style.cssText='font-size:12px;margin-top:7px;line-height:1.6';return e;}
 const strip=$('#playBtn').closest('.output-grid');strip.id='bwAlphaOutput';$('#playBtn').before(makeStop('bwAlphaStop'));
 const layout=document.createElement('style');layout.textContent='#bwAlphaOutput{grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}#bwAlphaOutput>#composeBtn,#bwAlphaOutput>#playBtn,#bwAlphaOutput>#bwAlphaStop{min-width:0;padding:6px 4px;font-size:10.5px;white-space:nowrap;min-height:34px}#bwAlphaOutput>.hotkey-btn{gap:2px}#bwAlphaOutput .hotkey-badge{font-size:7.5px;padding:1px 2px}#bwAlphaLiveActions{display:grid;grid-template-columns:1fr 1fr;gap:8px;flex-shrink:0}#bwAlphaLiveActions>button{width:100%;min-height:46px;margin:0}';document.head.append(layout);
 const status=makeStatus('bwAlphaStatus');strip.after(status);
 const liveActions=document.createElement('div');liveActions.id='bwAlphaLiveActions';$('#bw7LivePlay').before(liveActions);liveActions.append(makeStop('bwAlphaLiveStop'),$('#bw7LivePlay'));
 const liveStatus=makeStatus('bwAlphaLiveStatus');$('#bw71LiveOutput').after(liveStatus);
 const options=document.createElement('details');options.id='bwAlphaSettings';options.style.cssText='margin:12px 0;padding:10px;border:1px solid #28515c;border-radius:8px';options.innerHTML='<summary>直播输出设置</summary><label class="bw71-field" for="bwAlphaMode">输出方式<select id="bwAlphaMode"><option value="alpha">透明输出（默认）</option><option value="legacy">原版输出（兼容）</option></select></label><p class="bw71-note">透明输出会在视频结束或停止后自动恢复透明。切换输出方式前请先停止播放；原版输出使用另一采集窗口，需要在直播伴侣重新选择。每次启动默认使用透明输出。</p><div id="bwAlphaDiagnostics" style="font-size:12px;line-height:1.6"></div>';
 $('#bw71Dialog').querySelector('.bw71-field').before(options);
 const guideLabel=document.createElement('label');guideLabel.className='bw71-note';guideLabel.innerHTML='<input type="checkbox" id="bw817Guide" checked> 显示桌面拖动虚线框（直播采集排除）';options.querySelector('p').after(guideLabel);
 const guide=$('#bw817Guide');guide.checked=localStorage.getItem('bw817Guide')!=='0';guide.onchange=async()=>{localStorage.setItem('bw817Guide',guide.checked?'1':'0');if(alpha&&userOpened)try{await window.bw71.api('/api/app/alpha-guide',{show:guide.checked});}catch(e){toast(e.message);}};
 const mode=$('#bwAlphaMode');mode.onchange=async()=>{const desired=mode.value==='alpha';if(desired===alpha)return;if(!pv.paused||state.composing||window.bwQueueActivePlaying){mode.value=alpha?'alpha':'legacy';toast('请先停止播放并等待合成完成，再切换输出方式');return;}mode.disabled=true;try{blank();modeEpoch++;opening=null;stopNativeFramePump();const previous=state.nativeWS;try{if(previous){previous.onclose=null;previous.close();}}catch(_){}state.nativeWS=null;state.nativeOutputActive=false;if(alpha)await window.bw71.api('/api/app/alpha-close',{});alpha=desired;userOpened=false;visible=false;bind();updateStatus();toast(alpha?'已切换透明输出':'已切换原版输出，请在直播伴侣重新选择原版窗口');}finally{mode.disabled=false;}};
 async function toggleOutput(){
  if(opening)return;if(userOpened&&connected()){
   if(!pv.paused){toast('请先停止播放，再关闭输出窗口');return;}
   blank();userOpened=false;modeEpoch++;stopNativeFramePump();state.nativeWS?.close();state.nativeWS=null;state.nativeOutputActive=false;
   if(alpha)await window.bw71.api('/api/app/alpha-close',{});updateStatus();return;
  }
  try{if(alpha){await window.bw71.api('/api/app/alpha-open',{});userOpened=true;if(!await open())throw Error(lastError||'帧通道连接失败');await window.bw71.api('/api/app/alpha-guide',{show:guide.checked});}else{userOpened=true;await original.open();}updateStatus();}catch(e){toast('输出打开失败：'+e.message);}
 }
 function statusText(text,color){for(const e of [status,liveStatus]){e.textContent=text;e.style.color=color;}}
 let reading=false;async function updateStatus(){if(reading||unloading)return;for(const id of ['openOutputBtn','bw71LiveOutput'])$('#'+id).textContent=userOpened&&connected()?'关闭直播输出窗口':'打开直播输出窗口';reading=true;try{
  if(!alpha){statusText('输出状态：原版输出','#a5bbc1');$('#bwAlphaDiagnostics').textContent='原版兼容输出已启用；重新选择原版窗口素材。';return;}
  if(!connected()){const t=opening?'输出状态：正在连接…':'输出状态：'+(userOpened?'连接中断，请点击重新打开':'窗口未打开')+(lastError?' · '+lastError:'');statusText(t,'#ffd35a');$('#bwAlphaDiagnostics').textContent=t;return;}
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),1500);let h;try{h=await fetch(endpoint+'/health',{cache:'no-store',signal:abort.signal}).then(r=>r.json());}finally{clearTimeout(timer);}
  if(!alpha||!connected())return;const t='输出状态：已连接 · '+(h.mode==='video'?(pv.paused?'已暂停':'播放中'):'透明待机');statusText(t,'#36d9ba');$('#bwAlphaDiagnostics').textContent=t+' · 已显示 '+h.frames+' 帧'+(h.guideError?' · '+h.guideError:'')+(h.error?' · '+h.error:'');
 }catch(e){statusText('输出状态：组件未响应，请重新启动软件','#ffd35a');}finally{reading=false;}}
 updateStatus();setInterval(updateStatus,1000);
 document.title='美丽武器 V8.1.7 透明输出版';
 document.querySelector('.brand span').textContent='美丽武器 V8.1.7 · 透明输出版';
 window.bwAlpha={version:'1.7',userOpened:()=>userOpened,toggle:toggleOutput,visible:()=>visible,mode:()=>alpha?'alpha':'legacy',connected,blank,open,canvas,stop:stopPlayback};
 if(new URLSearchParams(location.search).get('alpha-self-test')==='1'){const s=document.createElement('script');s.src=endpoint+'/harness.js';document.body.append(s);}
})();
