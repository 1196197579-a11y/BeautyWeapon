﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly:System.Reflection.AssemblyTitle("Meili Live Alpha - V8.1.7 transparent output")]
[assembly:System.Reflection.AssemblyVersion("1.7.0.0")]
internal static class AlphaApp {
 internal static readonly string Root=Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\')).FullName;
 [STAThread] static void Main(){Application.EnableVisualStyles();try{using(var f=new AlphaPanel())Application.Run(f);}catch(Exception e){MessageBox.Show(e.Message,"透明输出组件",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
}
internal static class Win {
 [StructLayout(LayoutKind.Sequential)] internal struct Pt {public int X,Y;public Pt(int x,int y){X=x;Y=y;}}
 [StructLayout(LayoutKind.Sequential)] internal struct Sz {public int W,H;public Sz(int w,int h){W=w;H=h;}}
 [StructLayout(LayoutKind.Sequential,Pack=1)] internal struct Blend {public byte Op,Flags,Constant,Format;}
 [StructLayout(LayoutKind.Sequential)] internal struct Info {public uint Size;public int W,H;public ushort Planes,Bits;public uint Compression,ImageSize;public int XP,YP;public uint Used,Important;}
 [DllImport("gdi32.dll")] internal static extern IntPtr CreateCompatibleDC(IntPtr p);
 [DllImport("gdi32.dll")] internal static extern IntPtr CreateDIBSection(IntPtr d,ref Info i,uint usage,out IntPtr bits,IntPtr s,uint offset);
 [DllImport("gdi32.dll")] internal static extern IntPtr SelectObject(IntPtr d,IntPtr p);
 [DllImport("gdi32.dll")] internal static extern bool DeleteObject(IntPtr p);
 [DllImport("gdi32.dll")] internal static extern bool DeleteDC(IntPtr d);
 [DllImport("user32.dll",SetLastError=true)] internal static extern bool UpdateLayeredWindow(IntPtr h,IntPtr d,IntPtr pos,ref Sz size,IntPtr src,ref Pt p,uint key,ref Blend b,uint flags);
 [DllImport("user32.dll")]internal static extern IntPtr SendMessage(IntPtr h,uint msg,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] internal static extern bool ShowWindow(IntPtr h,int command);
 [DllImport("user32.dll")] internal static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int ht,uint flags);
}
internal sealed class LiveOutput:NativeWindow,IDisposable {
 internal const int W=1920,H=1080,N=W*H*4;
 internal const string Title="美丽武器 直播输出 | Meili Live Alpha";
 IntPtr dc,dib,bits,old;readonly Action close;internal DesktopGuide Guide;
 internal long Frames;internal int Transparent=N/4,Opaque;internal double ConvertMs;
 internal LiveOutput(Action onClose){close=onClose;var cp=new CreateParams{Caption=Title,X=0,Y=0,Width=W,Height=H,Style=unchecked((int)0x80000000),ExStyle=0x80000|0x40000};CreateHandle(cp);dc=Win.CreateCompatibleDC(IntPtr.Zero);var info=new Win.Info{Size=40,W=W,H=-H,Planes=1,Bits=32,ImageSize=N};dib=Win.CreateDIBSection(dc,ref info,0,out bits,IntPtr.Zero,0);if(dib==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());old=Win.SelectObject(dc,dib);Clear();Win.SendMessage(Handle,0x80,new IntPtr(0),System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath).Handle);Win.SendMessage(Handle,0x80,new IntPtr(1),System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath).Handle);Win.ShowWindow(Handle,4);Guide=new DesktopGuide(Handle);}
 internal unsafe void Frame(byte[] rgba){var sw=Stopwatch.StartNew();int zero=0,full=0;fixed(byte* src=rgba){uint* s=(uint*)src;uint* d=(uint*)bits;for(int i=0;i<W*H;i++){uint p=s[i],a=p>>24;if(a==255){d[i]=(p&0xff00ff00)|((p&255)<<16)|((p>>16)&255);full++;}else if(a==0){d[i]=0;zero++;}else{uint r=(p&255)*a/255,g=((p>>8)&255)*a/255,b=((p>>16)&255)*a/255;d[i]=(a<<24)|(r<<16)|(g<<8)|b;}}}Transparent=zero;Opaque=full;Present();Frames++;ConvertMs=sw.Elapsed.TotalMilliseconds;}
 internal unsafe void Clear(){uint* p=(uint*)bits;for(int i=0;i<W*H;i++)p[i]=0;Transparent=W*H;Opaque=0;Present();}
 internal void Marker(){using(var bmp=new Bitmap(W,H,W*4,PixelFormat.Format32bppPArgb,bits))using(var g=Graphics.FromImage(bmp)){g.Clear(Color.Transparent);g.FillRectangle(Brushes.Turquoise,24,24,660,94);using(var font=new Font("Microsoft YaHei",22,FontStyle.Bold))g.DrawString("美丽武器直播输出 · 播放时保留完整视频",font,Brushes.Black,38,48);}Present();}
 void Present(){var size=new Win.Sz(W,H);var p=new Win.Pt(0,0);var blend=new Win.Blend{Constant=255,Format=1};if(!Win.UpdateLayeredWindow(Handle,IntPtr.Zero,IntPtr.Zero,ref size,dc,ref p,0,ref blend,2))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}
 internal Color Pixel(int x,int y){int v=Marshal.ReadInt32(bits,(y*W+x)*4);return Color.FromArgb(v);}
 internal void Snapshot(string path){using(var bmp=new Bitmap(W,H,W*4,PixelFormat.Format32bppPArgb,bits))bmp.Save(path,ImageFormat.Png);}
 protected override void WndProc(ref Message m){if(m.Msg==0x3&&Guide!=null)Guide.Update();if(m.Msg==0x10){close();m.Result=IntPtr.Zero;return;}if(m.Msg==0x112&&((int)m.WParam&0xfff0)==0xf020){m.Result=IntPtr.Zero;return;}if(m.Msg==0x84){m.Result=new IntPtr(2);return;}base.WndProc(ref m);}
 public void Dispose(){if(Guide!=null)Guide.Dispose();if(dc!=IntPtr.Zero){if(old!=IntPtr.Zero)Win.SelectObject(dc,old);if(dib!=IntPtr.Zero)Win.DeleteObject(dib);Win.DeleteDC(dc);}if(Handle!=IntPtr.Zero)DestroyHandle();dc=IntPtr.Zero;}
}
internal sealed class AlphaPanel:Form {
 readonly LiveOutput output;readonly AlphaServer server;readonly System.Windows.Forms.Timer tick=new System.Windows.Forms.Timer();
 protected override void SetVisibleCore(bool visible){base.SetVisibleCore(false);}
 internal AlphaPanel(){ShowInTaskbar=false;Text="Meili output host";var h=Handle;output=new LiveOutput(()=>Close());server=new AlphaServer(this,output);server.Start();tick.Interval=16;tick.Tick+=(s,e)=>server.Draw();tick.Start();FormClosed+=(s,e)=>{tick.Stop();server.Dispose();output.Dispose();};}
}
internal sealed class AlphaServer:IDisposable {
 readonly AlphaPanel panel;readonly LiveOutput output;readonly TcpListener listener=new TcpListener(IPAddress.Loopback,38656);readonly object gate=new object();readonly Queue<byte[]> pool=new Queue<byte[]>();readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=1024*1024};readonly HashSet<TcpClient> clients=new HashSet<TcpClient>();
 volatile bool alive;byte[] latest;bool clear,drawPending;int connection;long received,dropped;DateTime heartbeat=DateTime.UtcNow;internal string Mode="idle";double clock;string error="";
 internal AlphaServer(AlphaPanel p,LiveOutput o){panel=p;output=o;for(int i=0;i<4;i++)pool.Enqueue(new byte[LiveOutput.N]);}
 internal void Start(){listener.Start();alive=true;new Thread(()=>{while(alive)try{var c=listener.AcceptTcpClient();c.NoDelay=true;lock(gate)clients.Add(c);ThreadPool.QueueUserWorkItem(_=>Handle(c));}catch{break;}}){IsBackground=true}.Start();}
 internal void Draw(){byte[] b=null;bool wipe=false;lock(gate){if(Mode!="idle"&&(DateTime.UtcNow-heartbeat).TotalSeconds>5){Mode="idle";clear=true;error="帧通道失联，已恢复透明";}if(clear){wipe=true;clear=false;}if(latest!=null){b=latest;latest=null;}}if(wipe)output.Clear();if(b!=null){if(Mode!="idle")output.Frame(b);lock(gate)pool.Enqueue(b);}}
 void PostDraw(){lock(gate){if(drawPending)return;drawPending=true;}try{panel.BeginInvoke(new Action(()=>{lock(gate)drawPending=false;Draw();}));}catch(InvalidOperationException){lock(gate)drawPending=false;}}
 byte[] Take(){lock(gate){if(pool.Count>0)return pool.Dequeue();if(latest!=null){var b=latest;latest=null;dropped++;return b;}return new byte[LiveOutput.N];}}
 void Return(byte[] b){if(b==null)return;lock(gate){if(pool.Count<5)pool.Enqueue(b);}}
 static void Read(Stream s,byte[] b,int off,int n){while(n>0){int r=s.Read(b,off,n);if(r<=0)throw new EndOfStreamException();off+=r;n-=r;}}
 static unsafe void Unmask(byte[] b,int off,int n,byte[] mask){uint key=(uint)(mask[0]|mask[1]<<8|mask[2]<<16|mask[3]<<24);fixed(byte* p=b){byte* start=p+off;int i=0;for(;i+4<=n;i+=4)*(uint*)(start+i)^=key;for(;i<n;i++)start[i]^=mask[i&3];}}
 static string Header(NetworkStream s){var b=new MemoryStream();int a=0;while(b.Length<16384){int c=s.ReadByte();if(c<0)throw new EndOfStreamException();b.WriteByte((byte)c);a=(a<<8)|c;if(a==0x0d0a0d0a)return Encoding.ASCII.GetString(b.ToArray());}throw new IOException("HTTP 头过大");}
 static Dictionary<string,string> Headers(string text){var d=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);foreach(var row in text.Split(new[]{"\r\n"},StringSplitOptions.None)){int i=row.IndexOf(':');if(i>0)d[row.Substring(0,i)]=row.Substring(i+1).Trim();}return d;}
 bool Origin(Dictionary<string,string> h){string v;return !h.TryGetValue("Origin",out v)||v=="http://127.0.0.1:38555"||v=="http://127.0.0.1:38656";}
 void Handle(TcpClient c){int mine=0;try{c.ReceiveTimeout=15000;var s=c.GetStream();string head=Header(s);var h=Headers(head);string[] first=head.Split('\n')[0].Trim().Split(' ');var uri=new Uri("http://127.0.0.1:38656"+first[1]);if(!Origin(h)){Reply(s,403,"text/plain",Encoding.UTF8.GetBytes("Origin denied"),null);return;}string upgrade;if(h.TryGetValue("Upgrade",out upgrade)&&upgrade.Equals("websocket",StringComparison.OrdinalIgnoreCase)&&uri.AbsolutePath=="/frame"){string key;if(!h.TryGetValue("Sec-WebSocket-Key",out key))throw new IOException("WebSocket key missing");lock(gate){mine=++connection;Mode="idle";clear=true;error="";heartbeat=DateTime.UtcNow;}string accept;using(var sha=SHA1.Create())accept=Convert.ToBase64String(sha.ComputeHash(Encoding.ASCII.GetBytes(key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11")));byte[] hello=Encoding.ASCII.GetBytes("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+accept+"\r\n\r\n");s.Write(hello,0,hello.Length);SocketLoop(s,mine);return;}
 if(first[0]=="OPTIONS"){Reply(s,200,"text/plain",new byte[0],h);return;}
 if(uri.AbsolutePath=="/close"){Reply(s,200,"application/json",Encoding.UTF8.GetBytes("{\"ok\":true}"),h);panel.BeginInvoke(new Action(()=>panel.Close()));return;}
 if(uri.AbsolutePath=="/guide-show"||uri.AbsolutePath=="/guide-hide"){object guide=panel.Invoke(new Func<object>(()=>{output.Guide.Show(uri.AbsolutePath=="/guide-show");return new{ok=true,visible=output.Guide.Visible,excluded=output.Guide.Excluded,error=output.Guide.Error};}));Reply(s,200,"application/json",Encoding.UTF8.GetBytes(json.Serialize(guide)),h);return;}
 if(uri.AbsolutePath=="/health"||uri.AbsolutePath=="/open"){object value=panel.Invoke(new Func<object>(()=>new{ok=true,root=AlphaApp.Root,title=LiveOutput.Title,hwnd=output.Handle.ToInt64(),pid=Process.GetCurrentProcess().Id,mode=Mode,frames=output.Frames,received=received,dropped=dropped,alpha0=output.Transparent,alpha255=output.Opaque,drawMs=output.ConvertMs,currentMs=clock,error=error,guideExcluded=output.Guide.Excluded,guideVisible=output.Guide.Visible,guideError=output.Guide.Error}));Reply(s,200,"application/json",Encoding.UTF8.GetBytes(json.Serialize(value)),h);return;}
 if(uri.AbsolutePath=="/snapshot"){string dir=Path.Combine(AlphaApp.Root,"testData","validation");Directory.CreateDirectory(dir);string p=Path.Combine(dir,"output-latest.png");panel.Invoke(new Action(()=>output.Snapshot(p)));Reply(s,200,"image/png",File.ReadAllBytes(p),h);return;}
 if(uri.AbsolutePath=="/test/report"&&first[0]=="POST"){int n=int.Parse(h["Content-Length"]);if(n>1024*1024)throw new IOException("Report too large");var body=new byte[n];Read(s,body,0,n);json.DeserializeObject(Encoding.UTF8.GetString(body));string dir=Path.Combine(AlphaApp.Root,"testData","validation");Directory.CreateDirectory(dir);File.WriteAllBytes(Path.Combine(dir,"browser-report.json"),body);Reply(s,200,"application/json",Encoding.UTF8.GetBytes("{\"ok\":true}"),h);return;}
 if(uri.AbsolutePath.StartsWith("/test-assets/",StringComparison.Ordinal)){string root=Path.Combine(AlphaApp.Root,"test_assets");string file=Path.GetFullPath(Path.Combine(root,Uri.UnescapeDataString(uri.AbsolutePath.Substring(13))));if(!file.StartsWith(root+"\\",StringComparison.OrdinalIgnoreCase)||!File.Exists(file))throw new FileNotFoundException();SendFile(s,file,h);return;}
 if(uri.AbsolutePath=="/harness.js"){SendFile(s,Path.Combine(AlphaApp.Root,"components","runtime","alpha","harness.js"),h);return;}
 Reply(s,404,"text/plain",new byte[0],h);
 }catch(Exception e){if(mine!=0 && !(e is EndOfStreamException))error=e.Message;}finally{lock(gate){clients.Remove(c);if(mine!=0&&mine==connection){Mode="idle";clear=true;if(latest!=null){pool.Enqueue(latest);latest=null;}}}c.Close();}}
 void SocketLoop(NetworkStream s,int mine){byte[] message=null;int used=0,opcode=0;try{while(alive){int one=s.ReadByte(),two=s.ReadByte();if(one<0||two<0)break;bool final=(one&128)!=0,masked=(two&128)!=0;int op=one&15;ulong len=(ulong)(two&127);if(len==126){var v=new byte[2];Read(s,v,0,2);len=(ulong)(v[0]*256+v[1]);}else if(len==127){var v=new byte[8];Read(s,v,0,8);len=0;foreach(byte n in v)len=(len<<8)|n;}if(!masked||len>LiveOutput.N||used+(long)len>LiveOutput.N)throw new IOException("Invalid frame");var mask=new byte[4];Read(s,mask,0,4);if(op>=8){if(!final||len>125)throw new IOException("Control frame");var small=new byte[(int)len];Read(s,small,0,small.Length);for(int i=0;i<small.Length;i++)small[i]^=mask[i%4];if(op==8)break;if(op==9){s.WriteByte(0x8a);s.WriteByte((byte)small.Length);s.Write(small,0,small.Length);}continue;}if(op!=0){if(message!=null)throw new IOException("Unexpected message");opcode=op;message=Take();used=0;}else if(message==null)throw new IOException("Unexpected continuation");Read(s,message,used,(int)len);Unmask(message,used,(int)len,mask);used+=(int)len;if(!final)continue;lock(gate){if(mine!=connection)break;heartbeat=DateTime.UtcNow;}
 if(used==LiveOutput.N&&opcode==2){lock(gate){received++;if(Mode!="idle"){if(latest!=null){pool.Enqueue(latest);dropped++;}latest=message;message=null;}}PostDraw();}
 else{string t=Encoding.UTF8.GetString(message,used>0&&message[0]==179?1:0,used-(used>0&&message[0]==179?1:0));var d=json.Deserialize<Dictionary<string,object>>(t);object v;lock(gate){if(d.TryGetValue("alphaMode",out v)){string m=Convert.ToString(v);if(m=="idle"){if(Mode!="idle")clear=true;Mode="idle";if(latest!=null){pool.Enqueue(latest);latest=null;}}else if(m=="video")Mode="video";}if(d.TryGetValue("currentMs",out v))clock=Convert.ToDouble(v);}}
 Return(message);message=null;used=0;
 }}finally{Return(message);}}
 void Reply(Stream s,int code,string type,byte[] body,Dictionary<string,string> h){string origin="http://127.0.0.1:38555";if(h!=null&&h.ContainsKey("Origin"))origin=h["Origin"];string header="HTTP/1.1 "+code+" OK\r\nConnection: close\r\nContent-Type: "+type+"\r\nContent-Length: "+body.Length+"\r\nAccess-Control-Allow-Origin: "+origin+"\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\nCache-Control: no-store\r\n\r\n";byte[] b=Encoding.ASCII.GetBytes(header);s.Write(b,0,b.Length);s.Write(body,0,body.Length);}
 void SendFile(Stream s,string file,Dictionary<string,string> h){using(var f=File.OpenRead(file)){long start=0,end=f.Length-1;int code=200;string range;if(h.TryGetValue("Range",out range)){var m=System.Text.RegularExpressions.Regex.Match(range,@"^bytes=(\d+)-(\d*)$");if(!m.Success)throw new IOException("Invalid range");start=long.Parse(m.Groups[1].Value);if(m.Groups[2].Value!="")end=Math.Min(end,long.Parse(m.Groups[2].Value));if(start>end||start>=f.Length)throw new IOException("Out of range");code=206;}string type=Path.GetExtension(file)==".mp4"?"video/mp4":Path.GetExtension(file)==".png"?"image/png":"text/javascript; charset=utf-8";string head="HTTP/1.1 "+code+" OK\r\nConnection: close\r\nContent-Type: "+type+"\r\nContent-Length: "+(end-start+1)+"\r\nAccept-Ranges: bytes\r\nAccess-Control-Allow-Origin: http://127.0.0.1:38555\r\n"+(code==206?"Content-Range: bytes "+start+"-"+end+"/"+f.Length+"\r\n":"")+"\r\n";var b=Encoding.ASCII.GetBytes(head);s.Write(b,0,b.Length);f.Position=start;var buf=new byte[131072];long left=end-start+1;while(left>0){int n=f.Read(buf,0,(int)Math.Min(buf.Length,left));if(n==0)break;s.Write(buf,0,n);left-=n;}}}
 public void Dispose(){alive=false;listener.Stop();lock(gate){foreach(var c in clients)c.Close();clients.Clear();}}
}
