(async()=>{
 const host='http://127.0.0.1:38656',results=[],timings=[];
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const health=()=>fetch(host+'/health').then(r=>r.json());
 async function until(fn,timeout=15000){const end=performance.now()+timeout;while(performance.now()<end){const v=await fn();if(v)return v;await sleep(80);}throw Error('等待超时');}
 function check(ok,name,detail){results.push({ok:!!ok,name,detail});if(!ok)throw Error(name+': '+JSON.stringify(detail));}
 async function snapshot(name){const blob=await fetch(host+'/snapshot').then(r=>r.blob());const image=await createImageBitmap(blob);const c=document.createElement('canvas');c.width=1920;c.height=1080;c.getContext('2d').drawImage(image,0,0);return c.getContext('2d').getImageData(0,0,1920,1080).data;}
 try{
  await sleep(1500);window.bw7Poll=async()=>{};state.autoReceive=false;state.locked=true;window.bw7.setRandomTemplates(false);$('#bw7Auto').checked=false;$('#bw7Auto').dispatchEvent(new Event('change'));await sleep(300);
  await window.bwAlpha.open();const initial=await health();check(initial.alpha0===2073600,'启动后全部像素透明',initial);
  const clip=await fetch(host+'/test-assets/'+encodeURIComponent('擦玻璃.mp4')).then(r=>r.blob());setVideoBlob(new File([clip],'擦玻璃.mp4',{type:'video/mp4'}),'擦玻璃.mp4');await waitMeta();check(pv.videoWidth===1290&&pv.videoHeight===720&&pv.duration>6,'指定真实视频载入', {width:pv.videoWidth,height:pv.videoHeight,duration:pv.duration});
  const av=document.createElement('canvas');av.width=av.height=160;const ag=av.getContext('2d');ag.fillStyle='#00ff00';ag.fillRect(0,0,160,160);ag.fillStyle='#000';ag.fillRect(35,35,90,90);ag.fillStyle='#fff';ag.font='bold 34px sans-serif';ag.fillText('TEST',37,93);
  state.profile={nickname:'透明验证·中文🙂',avatarDataUrl:av.toDataURL(),identityId:'alpha-test-only',sourceUrl:'https://www.douyin.com/user/alpha-test-only'};state.profileTs=Date.now();state.manualName='';nicknameInput.value='';renderProfile();await avatarImg.decode();$('#appearTime').value=0;$('#entryEffect').value='revealLeft';$('#fontSize').value=38;centerProfile();
  const deco=await fetch(host+'/test-assets/保色角标.png').then(r=>r.blob());await setDecoBlob(new File([deco],'保色角标.png',{type:'image/png'}),'保色角标.png',{resetLayout:true});
  const r=fitStage();decoLayer.style.left=(r.w*.63)+'px';decoLayer.style.top=(r.h*.76)+'px';decoLayer.style.width=(r.w*.33)+'px';decoLayer.style.height=(r.h*.18)+'px';renderAll();
  const at=performance.now();await doCompose();check(!!state.composedSrc&&state.composedKey===compKey(),'原合成流程完成：真实视频＋头像昵称＋图片＋渐显', {ms:performance.now()-at,bytes:state.composedBlob?.size});
  window.bwAlpha.clipBlob=state.composedBlob;
  await doPlay();await until(()=>!pv.paused&&pv.currentTime>1.2);pv.pause();await sleep(350);await until(()=>state.nativeWS.bufferedAmount===0);await sleep(250);let held=await health();check(held.alpha255===2073600&&held.mode==='video','播放帧所有像素不透明',held);
  const expected=window.bwAlpha.canvas.getContext('2d').getImageData(0,0,1920,1080).data,actual=await snapshot('paused');let different=0,maxDiff=0;for(let i=0;i<actual.length;i++){const d=Math.abs(actual[i]-expected[i]);if(d){different++;maxDiff=Math.max(maxDiff,d);}}check(different===0,'实际原生窗口帧与浏览器视频帧逐字节一致（无颜色抠除）',{different,maxDiff});
  const pos=pv.currentTime;await sleep(500);check(pv.currentTime===pos&&(await health()).alpha255===2073600,'暂停保持画面和播放位置');
  const records=[];const monitor=setInterval(async()=>{try{records.push({time:performance.now(),...(await health())});}catch(_){}},250);await pv.play();await until(()=>pv.ended||!window.bwAlpha.visible(),15000);await until(async()=>{const h=await health();return h.alpha0===2073600&&h.mode==='idle';});clearInterval(monitor);const ended=await health();check(ended.hwnd===initial.hwnd,'结束后全透明且采集句柄不变',ended);timings.push({phase:'real-composed-playback',records});
  await doPlay();await until(()=>!pv.paused&&pv.currentTime>.4);$('#bwAlphaStop').click();await until(async()=>{const h=await health();return pv.paused&&h.alpha0===2073600;});check(true,'停止播放恢复透明');
  await doPlay();await until(()=>!pv.paused&&pv.currentTime>.4);state.nativeWS.close();await until(async()=>{const h=await health();return h.alpha0===2073600;});check(true,'断开帧通道自动透明');pv.pause();await window.bwAlpha.open();check((await health()).hwnd===initial.hwnd,'重新连接保持同一采集窗口');
  const settings=await fetch('http://127.0.0.1:38560/api/app/settings').then(r=>r.json());
  const queue=async(action,data={})=>{const r=await fetch('http://127.0.0.1:38560/api/queue/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-BW-Session':settings.session},body:JSON.stringify(data)});const d=await r.json();if(!d.ok)throw Error(action+': '+d.error);return d;};
  for(const id of ['alpha-fixture-1','alpha-fixture-2'])await queue('restore',{taskId:id});
  await window.bw8.poll();check(window.bw8.state().tasks.filter(t=>t.status==='ready').length===2,'两个离线成片进入原队列（未模拟实时身份读取）');
  const queueHwnd=(await health()).hwnd;
  await window.bw8.playNext();await until(()=>window.bwQueueActivePlaying&&pv.currentTime>.5);check((await health()).alpha255===2073600,'队列第一条播放完整不透明');
  $('#bwAlphaStop').click();await until(async()=>{await window.bw8.poll();return !window.bwQueueActivePlaying&&(await health()).alpha0===2073600;});
  check(window.bw8.state().tasks.filter(t=>t.status==='ready').length===2,'中止队列播放恢复透明，并保留待播任务');
  const queueRecords=[];for(let n=0;n<2;n++){
   await window.bw8.playNext();await until(()=>window.bwQueueActivePlaying&&pv.currentTime>.5);
   queueRecords.push({phase:'playing-'+(n+1),...(await health())});
   await until(()=>!window.bwQueueActivePlaying,15000);await until(async()=>{const h=await health();return h.alpha0===2073600;});
   const h=await health();queueRecords.push({phase:'ended-'+(n+1),...h});check(h.hwnd===queueHwnd,'队列第'+(n+1)+'条自然结束恢复透明，同一窗口');
  }
  await window.bw8.poll();check(window.bw8.state().statistics.completed===2&&window.bw8.state().tasks.length===0,'原队列累计完成2条，无任务丢失');timings.push({phase:'offline-original-queue',records:queueRecords});
  const videoBytes=state.videoBlob.size,decoBytes=state.decoBlob.size,previousPrompt=window.prompt;window.prompt=()=> '正式版迁移验证模板';try{await $('#saveTemplateBtn').onclick();}finally{window.prompt=previousPrompt;}
  const exported=await window.bw7.exportTemplate();check(exported.filename.endsWith('.bwtemplate')&&exported.blob.size>videoBytes,'原模板及素材导出功能正常');
  const imported=await window.bw7.importTemplate(exported.blob);await window.bw7.loadTemplateById(imported.id);check(state.videoBlob.size===videoBytes&&state.decoBlob.size===decoBytes&&$('#entryEffect').value==='revealLeft','模板包导入加载后保留视频、图片和渐显设置');
  const completed={ok:true,results,timings,clip:'擦玻璃.mp4',sourceHasAudio:true,audioDecodedBytes:pv.webkitAudioDecodedByteCount||0,videoPlaybackQuality:pv.getVideoPlaybackQuality?.(),note:'队列验证使用明确离线测试任务；未验证实时抖音身份读取；音轨存在与解码不等于人工听感确认。'};await fetch(host+'/test/report',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(completed)});document.title='正式版回归验证通过';toast('自动验证通过；请查看验证报告。');
 }catch(e){await fetch(host+'/test/report',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ok:false,error:e.stack,results,timings,media:{readyState:pv.readyState,paused:pv.paused,currentTime:pv.currentTime},composition:{composing:state.composing,hasComposedVideo:!!state.composedSrc,keyMatches:state.composedKey===compKey()},ui:window.bw7?.state()})});document.title='透明副本验证需要修复';toast('自动验证异常：'+e.message);}
})();
