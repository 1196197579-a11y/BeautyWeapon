using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Web.Script.Serialization;
internal static class OutputManager {
 static readonly object gate=new object();static Process process;static LifetimeJob job;
 static string Root{get{return AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');}}
 static string Request(string route){var q=(HttpWebRequest)WebRequest.Create("http://127.0.0.1:38656/"+route);q.Proxy=null;q.Timeout=1200;using(var r=q.GetResponse())using(var s=new StreamReader(r.GetResponseStream()))return s.ReadToEnd();}
 static object Health(){var d=new JavaScriptSerializer().Deserialize<System.Collections.Generic.Dictionary<string,object>>(Request("health"));object root;if(!d.TryGetValue("root",out root)||!String.Equals(Convert.ToString(root),Root,StringComparison.OrdinalIgnoreCase))throw new IOException("输出端口被另一份软件占用，请先关闭那份软件的输出。");return d;}
 internal static object Open(){lock(gate){try{return Health();}catch(WebException){}job=new LifetimeJob();var s=new ProcessStartInfo(Path.Combine(Root,"components","Meili_Live_Alpha.exe")){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=Path.Combine(Root,"components")};process=Process.Start(s);try{job.Attach(process);}catch{try{process.Kill();}catch{}job.Dispose();job=null;throw;}for(int i=0;i<50;i++){Thread.Sleep(100);if(process.HasExited)throw new IOException("输出窗口未能启动。");try{return Health();}catch(WebException){}}throw new IOException("输出窗口未就绪。");}}
 internal static object Guide(bool show){lock(gate){Health();return new JavaScriptSerializer().DeserializeObject(Request(show?"guide-show":"guide-hide"));}}
 internal static object Close(){lock(gate){try{Health();Request("close");}catch{}if(process!=null){try{if(!process.WaitForExit(1800))process.Kill();}catch{}process.Dispose();process=null;}if(job!=null){job.Dispose();job=null;}return new{ok=true};}}
}
