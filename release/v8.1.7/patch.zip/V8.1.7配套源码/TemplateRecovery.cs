using System;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using System.Linq;
internal static class TemplateRecovery {
 static readonly object gate=new object();static string phase="idle",message="正在检查旧版模板",oldRoot="";static bool running;static int restored;
 static string Root{get{return AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');}}
 static string Store{get{return Path.Combine(Root,"testData","template-recovery");}}
 static JavaScriptSerializer Json(){return new JavaScriptSerializer{MaxJsonLength=300*1024*1024};}
 static string S(Dictionary<string,object>d,string k){object v;return d!=null&&d.TryGetValue(k,out v)?Convert.ToString(v):"";}
 static bool Same(string a,string b){return String.Equals(Path.GetFullPath(a).TrimEnd('\\'),Path.GetFullPath(b).TrimEnd('\\'),StringComparison.OrdinalIgnoreCase);}
 static string Hash(string p){using(var h=SHA256.Create())using(var f=File.OpenRead(p))return BitConverter.ToString(h.ComputeHash(f)).Replace("-","").ToLowerInvariant();}
 static void Safe(string p){if((File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)throw new IOException("旧配置含链接路径，停止迁移。");}
 static void CopyTree(string from,string into){if(!Directory.Exists(from))return;Safe(from);Directory.CreateDirectory(into);foreach(string p in Directory.GetFiles(from)){Safe(p);string dest=Path.Combine(into,Path.GetFileName(p));if(File.Exists(dest))throw new IOException("配置目标已有文件，未覆盖。");string before=Hash(p);File.Copy(p,dest,false);if(Hash(dest)!=before||Hash(p)!=before)throw new IOException("旧配置复制校验失败。");}foreach(string p in Directory.GetDirectories(from))CopyTree(p,Path.Combine(into,Path.GetFileName(p)));}
 static void CopyProfile(string from,string into){foreach(string rel in new[]{@"Default\Local Storage\leveldb",@"Default\IndexedDB"})CopyTree(Path.Combine(from,rel),Path.Combine(into,rel));}
 static IEnumerable<string> Activations(string dir){if(!Directory.Exists(dir))yield break;Safe(dir);string[] dirs;try{dirs=Directory.GetDirectories(dir);}catch(UnauthorizedAccessException){yield break;}foreach(string sub in dirs){Safe(sub);string p=Path.Combine(sub,"activation.json");if(File.Exists(p))yield return p;}}
 static string Discover(){
  var parents=new List<string>();string parent=Directory.GetParent(Root).FullName;
  foreach(string p in Directory.GetDirectories(parent,"美丽武器V*"))if(!Same(p,Root)){parents.Add(p);foreach(string file in Activations(Path.Combine(p,"testData","updates")))try{var d=Json().Deserialize<Dictionary<string,object>>(File.ReadAllText(file,Encoding.UTF8));if(S(d,"root")!=""&&Same(S(d,"root"),Root)&&Directory.Exists(S(d,"oldRoot")))return S(d,"oldRoot");}catch{}}
  foreach(string file in Activations(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BeautyWeapon","updates")))try{var d=Json().Deserialize<Dictionary<string,object>>(File.ReadAllText(file,Encoding.UTF8));if(S(d,"root")!=""&&Same(S(d,"root"),Root)&&Directory.Exists(S(d,"oldRoot")))return S(d,"oldRoot");}catch{}
  string desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);string current=Path.Combine(desktop,"美丽武器V8.1.6_透明输出版");if(Directory.Exists(current))return current;
  return parents.Where(p=>Directory.Exists(Path.Combine(p,"components","test-profiles","BeautyWeaponUI"))).OrderByDescending(p=>Directory.GetLastWriteTimeUtc(p)).FirstOrDefault()??"";
 }
 internal static void Prepare(){
  Directory.CreateDirectory(Store);string note=Path.Combine(Store,"migration.json");if(File.Exists(note)){try{oldRoot=S(Json().Deserialize<Dictionary<string,object>>(File.ReadAllText(note,Encoding.UTF8)),"oldRoot");}catch{}return;}
  oldRoot=Discover();string target=Path.Combine(Root,"components","test-profiles","BeautyWeaponUI");
  if(oldRoot!=""){
   string prior=Path.Combine(oldRoot,"components","test-profiles","BeautyWeaponUI");if(!Directory.Exists(prior))prior=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),"..","BeautyWeaponUI");
   if(!Directory.Exists(Path.Combine(target,"Default","Local Storage"))&&!Directory.Exists(Path.Combine(target,"Default","IndexedDB"))&&Directory.Exists(prior))CopyProfile(prior,target);
   foreach(string rel in new[]{@"components\test-profiles\BeautyWeaponV66",@"testData\automation-v8",@"testData\读取失败日志"}){string source=Path.Combine(oldRoot,rel),dest=Path.Combine(Root,rel);if(Directory.Exists(source)&&!Directory.Exists(dest))CopyTree(source,dest);}
   string settings=Path.Combine(oldRoot,"testData","settings.json"),into=Path.Combine(Root,"testData","settings.json");if(File.Exists(settings)&&!File.Exists(into)){File.Copy(settings,into,false);if(Hash(settings)!=Hash(into))throw new IOException("设置迁移校验失败。");}
   // The old alpha release may leave its independent output alive during activation.
   foreach(var p in Process.GetProcessesByName("Meili_Live_Alpha"))using(p)try{if(Same(Path.GetDirectoryName(p.MainModule.FileName),Path.Combine(oldRoot,"components"))){p.Kill();p.WaitForExit(2500);}}catch{}
  }
  File.WriteAllText(note,Json().Serialize(new{oldRoot=oldRoot,target=Root,sourceUnchanged=true,date=DateTime.Now.ToString("o")}),new UTF8Encoding(false));
 }
 internal static object State(){lock(gate){object manifest=null;string p=Path.Combine(Store,"manifest.json");if(phase=="ready"&&File.Exists(p))manifest=Json().DeserializeObject(File.ReadAllText(p,Encoding.UTF8));return new{ok=true,phase=phase,message=message,restored=restored,manifest=manifest};}}
 internal static void Applied(int count){lock(gate){restored=count;phase="complete";message="旧模板检查完成，已恢复 "+count+" 套；现有模板保持原样";File.WriteAllText(Path.Combine(Store,"applied.json"),Json().Serialize(new{count=count,date=DateTime.Now.ToString("o")}),new UTF8Encoding(false));}}
 internal static string Asset(string key){if(!System.Text.RegularExpressions.Regex.IsMatch(key??"","^[a-f0-9]{64}$"))throw new IOException("恢复素材键无效");string p=Path.Combine(Store,"assets",key);if(!File.Exists(p)||Hash(p)!=key)throw new IOException("恢复素材校验失败");return p;}
 internal static void Start(){lock(gate){if(running)return;if(File.Exists(Path.Combine(Store,"applied.json"))){phase="complete";message="旧模板恢复已完成";return;}running=true;phase="checking";}ThreadPool.QueueUserWorkItem(_=>{try{Export();lock(gate){phase="ready";message="旧模板已读取，正在恢复到列表";}}catch(Exception e){lock(gate){phase="error";message="旧模板恢复失败："+e.Message+"；原数据保留";}}finally{lock(gate)running=false;}});}
 static void Export(){
  string finished=Path.Combine(Store,"manifest.json");if(File.Exists(finished))return;
  var sources=new List<string>();if(oldRoot!="")sources.Add(Path.Combine(oldRoot,"components","test-profiles","BeautyWeaponUI"));sources.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),"..","BeautyWeaponUI"));
  var items=new List<Dictionary<string,object>>();var ids=new HashSet<string>();int index=0;
  foreach(string source in sources.Distinct(StringComparer.OrdinalIgnoreCase)){if(!Directory.Exists(Path.Combine(source,"Default","IndexedDB")))continue;string snapshot=Path.Combine(Store,"snapshots",(++index)+"_"+Guid.NewGuid().ToString("N").Substring(0,6));CopyProfile(source,snapshot);
   using(var browser=new RecoveryBrowser(snapshot)){
    var listed=browser.Eval("JSON.parse(localStorage.getItem('beauty_weapon_v64_templates')||'[]')") as System.Collections.IEnumerable;if(listed==null)throw new IOException("模板列表格式无法读取");
    foreach(object raw in listed){var t=raw as Dictionary<string,object>;if(t==null||S(t,"id")==""||ids.Contains(S(t,"id")))continue;var assets=new Dictionary<string,object>();bool missing=false;
     foreach(string kind in new[]{"video","font","deco"}){string key="tpl:"+S(t,"id")+":"+kind;var d=browser.Eval("(async()=>{const b=await _get("+Json().Serialize(key)+");if(!(b instanceof Blob))return null;const bytes=new Uint8Array(await b.arrayBuffer());let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return {data:btoa(s),name:b.name||'',type:b.type,size:b.size};})()") as Dictionary<string,object>;if(d==null){assets[kind]=null;if(kind=="video")missing=true;continue;}byte[] bytes=Convert.FromBase64String(S(d,"data"));if(bytes.Length!=Convert.ToInt64(d["size"]))throw new IOException("恢复素材大小不匹配");string hash;using(var h=SHA256.Create())hash=BitConverter.ToString(h.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();string path=Path.Combine(Store,"assets",hash);Directory.CreateDirectory(Path.GetDirectoryName(path));if(!File.Exists(path))File.WriteAllBytes(path,bytes);if(Hash(path)!=hash)throw new IOException("恢复素材保存校验失败");assets[kind]=new{name=S(d,"name"),type=S(d,"type"),size=bytes.Length,sha256=hash};}
     if(missing)continue;t["recoveryAssets"]=assets;items.Add(t);ids.Add(S(t,"id"));
    }
   }
  }
  File.WriteAllText(finished,Json().Serialize(new{templates=items.ToArray(),sourceUnchanged=true}),new UTF8Encoding(false));
 }
 sealed class RecoveryBrowser:IDisposable {
  readonly ClientWebSocket ws=new ClientWebSocket();readonly LifetimeJob job=new LifetimeJob();readonly Process process;int serial;
  internal RecoveryBrowser(string profile){string edge=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),@"Microsoft\Edge\Application\msedge.exe");if(!File.Exists(edge))edge=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"Microsoft\Edge\Application\msedge.exe");process=Process.Start(new ProcessStartInfo(edge,"--headless=new --disable-gpu --disable-background-networking --no-first-run --no-default-browser-check --remote-debugging-port=0 --user-data-dir=\""+profile+"\" about:blank"){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden});job.Attach(process);string portFile=Path.Combine(profile,"DevToolsActivePort");for(int i=0;i<150&&!File.Exists(portFile);i++){if(process.HasExited)throw new IOException("模板读取浏览器未启动");Thread.Sleep(100);}string port=File.ReadAllLines(portFile)[0];string list;using(var c=new WebClient())list=c.DownloadString("http://127.0.0.1:"+port+"/json/list");var targets=Json().Deserialize<List<Dictionary<string,object>>>(list);var page=targets.First(x=>S(x,"type")=="page");using(var token=new CancellationTokenSource(15000))ws.ConnectAsync(new Uri(S(page,"webSocketDebuggerUrl")),token.Token).GetAwaiter().GetResult();Call("Fetch.enable",new{patterns=new[]{new{urlPattern="http://127.0.0.1:38555/*"}}});Call("Page.enable",new{});Call("Page.navigate",new{url="http://127.0.0.1:38555/offline-template-recovery"});Eval("window._db=null;window._get=async k=>{if(!_db)_db=await new Promise((r,j)=>{const q=indexedDB.open('BeautyWeaponV61Assets');q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error)});return new Promise((r,j)=>{const q=_db.transaction('assets').objectStore('assets').get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error)});};true");}
  void Send(int id,string method,object args){byte[] b=Encoding.UTF8.GetBytes(Json().Serialize(new{id=id,method=method,@params=args}));using(var token=new CancellationTokenSource(60000))ws.SendAsync(new ArraySegment<byte>(b),WebSocketMessageType.Text,true,token.Token).GetAwaiter().GetResult();}
  Dictionary<string,object> Receive(){using(var memory=new MemoryStream())using(var token=new CancellationTokenSource(60000)){var b=new byte[65536];WebSocketReceiveResult r;do{r=ws.ReceiveAsync(new ArraySegment<byte>(b),token.Token).GetAwaiter().GetResult();if(r.MessageType==WebSocketMessageType.Close)throw new IOException("模板读取连接关闭");memory.Write(b,0,r.Count);if(memory.Length>300L*1024*1024)throw new IOException("模板读取数据过大");}while(!r.EndOfMessage);return Json().Deserialize<Dictionary<string,object>>(Encoding.UTF8.GetString(memory.ToArray()));}}
  Dictionary<string,object> Call(string method,object args){int id=++serial;Send(id,method,args);while(true){var m=Receive();if(S(m,"method")=="Fetch.requestPaused"){var p=(Dictionary<string,object>)m["params"];Send(++serial,"Fetch.fulfillRequest",new{requestId=S(p,"requestId"),responseCode=200,responseHeaders=new[]{new{name="Content-Type",value="text/html"}},body=Convert.ToBase64String(Encoding.UTF8.GetBytes("<!doctype html><title>Offline template recovery</title>"))});continue;}object n;if(m.TryGetValue("id",out n)&&Convert.ToInt32(n)==id){if(m.ContainsKey("error"))throw new IOException("模板浏览器请求失败");return m["result"] as Dictionary<string,object>;}}}
  internal object Eval(string expression){var d=Call("Runtime.evaluate",new{expression=expression,awaitPromise=true,returnByValue=true});if(d.ContainsKey("exceptionDetails"))throw new IOException("模板数据无法读取："+Json().Serialize(d["exceptionDetails"]));var value=(Dictionary<string,object>)d["result"];object v;return value.TryGetValue("value",out v)?v:null;}
  public void Dispose(){try{ws.Dispose();}catch{}job.Dispose();try{process.WaitForExit(2500);process.Dispose();}catch{}}
 }
}
