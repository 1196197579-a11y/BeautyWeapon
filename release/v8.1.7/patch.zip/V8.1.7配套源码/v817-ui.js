/* Preserve user assets; explicitly choose between queue and homepage backup. */
(()=>{
 'use strict';if(window.BW_QUEUE_WORKER)return;
 const bridge='http://127.0.0.1:38560';let applying=false,recoveryDone=false;
 const note=document.createElement('small');note.id='bw817Recovery';note.style.cssText='display:block;margin:6px 0;color:#a6ccd0;overflow-wrap:anywhere';$('#bw81Templates').append(note);
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 async function recovery(){if(applying||recoveryDone)return;applying=true;try{
  const r=await fetch(bridge+'/api/app/recovery-state',{cache:'no-store'}).then(r=>r.json());note.textContent=r.message;
  if(r.phase==='complete'){recoveryDone=true;return;}if(r.phase!=='ready')return;
  const list=templateIndex();let restored=0;
  for(const raw of r.manifest.templates){const existing=list.find(t=>t.id===raw.id),t=existing||structuredClone(raw);
   for(const k of ['video','font','deco']){const a=raw.recoveryAssets[k];if(!a||await idbGet('tpl:'+raw.id+':'+k))continue;
    const response=await fetch(bridge+'/api/app/recovery-asset?key='+a.sha256,{cache:'no-store'});if(!response.ok)throw Error('旧模板素材读取失败');const bytes=await response.arrayBuffer();const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');if(hash!==a.sha256||bytes.byteLength!==a.size)throw Error('旧模板素材校验失败');
    await idbPut('tpl:'+raw.id+':'+k,new File([bytes],a.name||raw.assets?.[k]?.name||k,{type:a.type||raw.assets?.[k]?.type||''}));
   }
   if(!existing){delete t.recoveryAssets;if(list.some(x=>x.name===t.name))t.name+='（旧版恢复）';list.push(t);restored++;saveTemplateIndex(list);}
  }
  refreshTemplates($('#templateSelect').value);await window.bw71.api('/api/app/recovery-applied',{count:restored});note.textContent='已恢复 '+restored+' 套旧模板，现有模板保留';recoveryDone=true;
 }catch(e){note.textContent='恢复未完成：'+e.message+'；原数据保留，稍后重试';}finally{applying=false;}}
 setInterval(recovery,2200);setTimeout(recovery,1200);
 const box=document.createElement('div');box.style.cssText='margin:12px 0;padding:10px;border:1px solid #28515c;border-radius:8px';box.innerHTML='<strong>主页备用合成</strong><p class="bw71-note">自动队列识别失败时，启用此方案并手动打开送礼用户的抖音主页。网页助手读到完整头像和昵称后自动合成；核对后点击播放。备用方案会暂停队列，已有任务保留。</p><button id="bw817FallbackBtn" class="secondary">启用主页备用合成</button><small id="bw817FallbackStatus" style="display:block;margin-top:6px"></small>';
 $('#bwAlphaSettings').after(box);
 const quick=document.createElement('button');quick.id='bw817FallbackQuick';quick.className='secondary';quick.style.cssText='margin:6px 0';$('#bw7LiveStatus').after(quick);
 function label(){const text=window.bw817Fallback?'返回自动队列':'启用主页备用合成';$('#bw817FallbackBtn').textContent=quick.textContent=text;$('#bw817FallbackStatus').textContent=window.bw817Fallback?'备用方案已启用：手动打开用户主页即可读取并合成':'当前使用自动队列';}
 async function fallback(value,initial=false){if(state.composing||!pv.paused||window.bwQueueActivePlaying){toast('请先停止播放并等待合成完成');return false;}window.bw817Switching=true;
  try{await window.bw8.poll();const q=window.bw8.state();if(q.tasks.some(t=>['composing','resolving','playing'].includes(t.status))){toast('请等待当前任务处理结束后切换');return false;}
   if(value){if(!initial)localStorage.setItem('bw817QueueBeforeFallback',q.enabled?'1':'0');await window.bwQueueApi('config',{enabled:false});window.bw817Fallback=true;state.autoReceive=true;$('#autoReceive').checked=true;state.locked=false;$('#lockProfile').textContent='锁定当前用户';$('#bw7Auto').checked=true;$('#bw7Auto').dispatchEvent(new Event('change'));}
   else{window.bw817Fallback=false;await window.bwQueueApi('config',{enabled:localStorage.getItem('bw817QueueBeforeFallback')==='1'});}
   localStorage.setItem('bw817Fallback',value?'1':'0');await window.bw8.poll();await window.bw7Poll();label();toast(value?'已启用主页备用合成；请手动打开送礼用户主页':'已返回自动队列');return true;
  }catch(e){toast('切换失败：'+e.message);return false;}finally{window.bw817Switching=false;label();}}
 $('#bw817FallbackBtn').onclick=quick.onclick=()=>fallback(!window.bw817Fallback);label();
 if(window.bw817Fallback)setTimeout(()=>fallback(true,true),1100);
 const enabled=$('#bw8Enabled'),prior=enabled.onchange;enabled.onchange=async()=>{if(window.bw817Fallback){enabled.checked=false;toast('请先返回自动队列，再开启自动监听');return;}return prior();};
 const ontime=pv.ontimeupdate;pv.ontimeupdate=function(...args){ontime?.apply(this,args);if(state.composing)$('#composeBtn').querySelector('span').textContent='合成中...';};
 window.bw817={fallback,recovery,status:()=>({fallback:window.bw817Fallback,recoveryDone})};
})();
