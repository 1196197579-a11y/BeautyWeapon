window.bw817Fallback=!window.BW_QUEUE_WORKER&&localStorage.getItem('bw817Fallback')==='1';
(() => {

  // Ship a pinned, licensed color font locally. Never fetch fonts from a remote
  // service during a broadcast; profile rendering waits for this font to load.
  const emojiFace=new FontFace('BeautyWeaponEmoji','url(http://127.0.0.1:38560/assets/emoji-font.ttf?v=8.1.7)',{unicodeRange:'U+200D,U+20E3,U+203C-2049,U+2190-21FF,U+2300-23FF,U+25A0-27FF,U+2934-2935,U+2B00-2BFF,U+3030-303D,U+3297-3299,U+FE0E-FE0F,U+1F000-1FFFF,U+E0020-E007F'});
  document.fonts.add(emojiFace);
  let emojiFontError='';
  const emojiFontReady=emojiFace.load().then(()=>{renderProfile();return true;}).catch(e=>{emojiFontError='离线 Emoji 字体加载失败，请完整安装新版：'+e.message;return false;});
  window.bwEmojiFont={ready:emojiFontReady,status:()=>emojiFace.status};
  const withEmojiFont=font=>typeof font==='string'&&font.includes('Segoe UI Emoji')?font.replace(/(\d+(?:\.\d+)?px)\s+/,'$1 "BeautyWeaponEmoji", '):font;
  const sceneFont=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'font');
  Object.defineProperty(sceneCtx,'font',{get(){return sceneFont.get.call(this);},set(value){sceneFont.set.call(this,withEmojiFont(value));},configurable:true});
  const renderProfileWithFont=renderProfile;
  renderProfile=function(...args){const result=renderProfileWithFont(...args);nameText.style.fontFamily='"BeautyWeaponEmoji", '+(state.fontFamily?'"'+state.fontFamily+'"':'"Microsoft YaHei"')+', "Segoe UI Emoji", sans-serif';return result;};

  // Directional reveal: shared one-second, 12% feathered horizontal mask.
  const revealDuration = 1;
  const revealDirection = () => ({revealLeft:'left',revealRight:'right'}[$('#entryEffect').value] || '');
  const effectSelect = $('#entryEffect');
  effectSelect.add(new Option('向左渐显', 'revealLeft'));
  effectSelect.add(new Option('向右渐显', 'revealRight'));
  if (startupState && /^(revealLeft|revealRight)$/.test(startupState.entryEffect)) effectSelect.value = startupState.entryEffect;
  const originalFxState = fxState;
  fxState = function () {
    if (!revealDirection()) return originalFxState();
    return {alpha:shouldShow()?1:0,scale:1,dx:0,glow:0};
  };
  const revealCanvas = document.createElement('canvas');
  revealCanvas.width=1920; revealCanvas.height=1080;
  const revealCtx = revealCanvas.getContext('2d');
  function drawReveal(draw, fx, bounds) {
    const direction = revealDirection();
    if (!direction) return draw(fx);
    const p = Math.max(0,Math.min(1,((pv.currentTime||0)-Number($('#appearTime').value||0))/revealDuration));
    if (!p || !fx.alpha) return;
    revealCtx.clearRect(0,0,1920,1080);
    draw(fx);
    if (p < 1) {
      const edge = p*1.12;
      const a = direction==='right' ? bounds.x+(edge-.12)*bounds.w : bounds.x+(1-edge)*bounds.w;
      const b = a+.12*bounds.w;
      const gradient = revealCtx.createLinearGradient(a,0,b,0);
      gradient.addColorStop(0,direction==='right'?'#000':'transparent');
      gradient.addColorStop(1,direction==='right'?'transparent':'#000');
      revealCtx.save(); revealCtx.globalCompositeOperation='destination-in';
      revealCtx.fillStyle=gradient; revealCtx.fillRect(0,0,1920,1080); revealCtx.restore();
    }
    sceneCtx.drawImage(revealCanvas,0,0);
  }
  const originalDrawDeco = drawDecoToScene, originalDrawProfile = drawProfileToScene;
  function drawRevealDeco(fx){if(!state.decoSrc||!shouldShow()||!decoImg.complete||!decoImg.naturalWidth)return;const r=sceneRect(decoLayer),cx=r.x+r.w/2,cy=r.y+r.h/2;revealCtx.save();revealCtx.globalAlpha=fx.alpha;revealCtx.translate(cx+fx.dx*(1920/Math.max(1,fitStage().w)),cy);revealCtx.scale(fx.scale,fx.scale);if(fx.glow){revealCtx.shadowColor='rgba(76,227,194,.8)';revealCtx.shadowBlur=24*fx.glow}revealCtx.drawImage(decoImg,-r.w/2,-r.h/2,r.w,r.h);revealCtx.restore()}
  function drawRevealProfile(fx){if(!hasProfileVisual()||!shouldShow())return;const r=sceneRect(profileBox),sc=sceneScale(),av=avatarSrc(),avatarCss=parseFloat(avatarWrap.style.width)||70,avatarSize=av?avatarCss*sc.sx:0,gap=av?10*sc.sx:0,effective=Number(nameText.dataset.effectiveSize||$('#fontSize').value||38),fontPx=effective*sc.sx,name=displayName(activeName());revealCtx.save();let fontFamily=state.fontFamily?`"${state.fontFamily}"`:'"Microsoft YaHei"';revealCtx.font=`900 ${fontPx}px "BeautyWeaponEmoji", ${fontFamily}, "Segoe UI Emoji", "Microsoft YaHei", sans-serif`;revealCtx.textBaseline='middle';revealCtx.textAlign='left';const textW=revealCtx.measureText(name).width,totalW=avatarSize+(av?gap:0)+textW,cx=r.x+r.w/2,cy=r.y+r.h/2;revealCtx.globalAlpha=fx.alpha;revealCtx.translate(cx+fx.dx*sc.sx,cy);revealCtx.scale(fx.scale,fx.scale);if(fx.glow){revealCtx.shadowColor='rgba(76,227,194,.75)';revealCtx.shadowBlur=20*fx.glow}let x=-totalW/2;if(av&&avatarImg.complete&&avatarImg.naturalWidth){revealCtx.save();revealCtx.beginPath();revealCtx.arc(x+avatarSize/2,0,avatarSize/2,0,Math.PI*2);revealCtx.clip();revealCtx.drawImage(avatarImg,x,-avatarSize/2,avatarSize,avatarSize);revealCtx.restore();revealCtx.save();revealCtx.strokeStyle='rgba(255,255,255,.95)';revealCtx.lineWidth=Math.max(2,3*sc.sx);revealCtx.beginPath();revealCtx.arc(x+avatarSize/2,0,avatarSize/2-revealCtx.lineWidth/2,0,Math.PI*2);revealCtx.stroke();revealCtx.restore();x+=avatarSize+gap}revealCtx.fillStyle=$('#textColor').value||'#ffffff';revealCtx.shadowColor='transparent';revealCtx.shadowBlur=0;revealCtx.fillText(name,x,0);revealCtx.restore()}
  drawDecoToScene = function(fx) {
    if (!revealDirection()) return originalDrawDeco(fx);
    drawReveal(drawRevealDeco,fx,sceneRect(decoLayer));
  };
  drawProfileToScene = function(fx) {
    if (!revealDirection()) return originalDrawProfile(fx);
    const r=sceneRect(profileBox), sc=sceneScale(), av=avatarSrc();
    const fontPx=Number(nameText.dataset.effectiveSize||$('#fontSize').value||38)*sc.sx;
    revealCtx.font='900 '+fontPx+'px "BeautyWeaponEmoji", '+(state.fontFamily?'"'+state.fontFamily+'"':'"Microsoft YaHei"')+', "Segoe UI Emoji", "Microsoft YaHei", sans-serif';
    const pad=Math.max(8,Math.ceil(5*sc.sx));
    const w=Math.max(2,Math.ceil((av?(parseFloat(avatarWrap.style.width)||70)*sc.sx+10*sc.sx:0)+revealCtx.measureText(displayName(activeName())).width+pad*2));
    drawReveal(drawRevealProfile,fx,{x:r.x+r.w/2-w/2,w});
  };
  async function markReveal(blob) {
    const direction=revealDirection();
    if (!direction) return blob;
    let bytes=new Uint8Array(await blob.arrayBuffer());
    if (bytes[0]!==137 || bytes[1]!==80 || bytes[2]!==78 || bytes[3]!==71) {
      const bitmap=await createImageBitmap(blob), c=document.createElement('canvas');
      c.width=bitmap.width;c.height=bitmap.height;c.getContext('2d').drawImage(bitmap,0,0);bitmap.close();
      bytes=new Uint8Array(await (await canvasBlob(c)).arrayBuffer());
    }
    const data=new TextEncoder().encode('tEXtBeautyWeapon\0BW_REVEAL_V1:'+direction);
    const chunk=new Uint8Array(data.length+8), view=new DataView(chunk.buffer);
    view.setUint32(0,data.length-4);chunk.set(data,4);
    let crc=0xffffffff;
    for(const byte of data){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}
    view.setUint32(chunk.length-4,(crc^0xffffffff)>>>0);
    return new Blob([bytes.subarray(0,bytes.length-12),chunk,bytes.subarray(bytes.length-12)],{type:'image/png'});
  }

  const SERVICE = 'http://127.0.0.1:38557';

  const canvasBlob = (canvas) => new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('PNG生成失败')), 'image/png');
  });

  async function buildProfilePng() {
    if (!hasProfileVisual()) return null;
    if(!await emojiFontReady)throw new Error(emojiFontError);
    await document.fonts.ready;
    try {
      if (avatarSrc() && avatarImg.decode) await avatarImg.decode();
    } catch (_) {}

    const sc = sceneScale();
    const av = avatarSrc();
    const avatarSize = av ? (parseFloat(avatarWrap.style.width) || 70) * sc.sx : 0;
    const gap = av ? 10 * sc.sx : 0;
    const effective = Number(nameText.dataset.effectiveSize || $('#fontSize').value || 38);
    const fontPx = effective * sc.sx;
    const name = displayName(activeName());
    const fontFamily = state.fontFamily ? `"${state.fontFamily}"` : '"Microsoft YaHei"';

    const c = document.createElement('canvas');
    let ctx = c.getContext('2d');
    ctx.font = `900 ${fontPx}px "BeautyWeaponEmoji", ${fontFamily}, "Segoe UI Emoji", "Microsoft YaHei", sans-serif`;
    const textW = ctx.measureText(name).width;
    const pad = Math.max(8, Math.ceil(5 * sc.sx));
    c.width = Math.max(2, Math.ceil(avatarSize + (av ? gap : 0) + textW + pad * 2));
    c.height = Math.max(2, Math.ceil(Math.max(avatarSize, fontPx * 1.45) + pad * 2));

    ctx = c.getContext('2d');
    ctx.font = `900 ${fontPx}px "BeautyWeaponEmoji", ${fontFamily}, "Segoe UI Emoji", "Microsoft YaHei", sans-serif`;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    const cy = c.height / 2;
    let x = pad;

    if (av && avatarImg.complete && avatarImg.naturalWidth) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(x + avatarSize / 2, cy, avatarSize / 2, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(avatarImg, x, cy - avatarSize / 2, avatarSize, avatarSize);
      ctx.restore();

      ctx.save();
      ctx.strokeStyle = 'rgba(255,255,255,.95)';
      ctx.lineWidth = Math.max(2, 3 * sc.sx);
      ctx.beginPath();
      ctx.arc(x + avatarSize / 2, cy, avatarSize / 2 - ctx.lineWidth / 2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      x += avatarSize + gap;
    }

    ctx.fillStyle = $('#textColor').value || '#ffffff';
    ctx.fillText(name, x, cy);

    const r = sceneRect(profileBox);
    return {
      blob: await canvasBlob(c),
      cx: r.x + r.w / 2,
      cy: r.y + r.h / 2,
      w: c.width,
      h: c.height
    };
  }

  async function ensureFFmpeg(span) {
    let health;
    try {
      health = await fetch(`${SERVICE}/ffmpeg-health`).then(r => r.json());
    } catch (e) {
      throw new Error('离线合成服务未启动');
    }
    if (health.ok) return health;

    span.textContent = '合成中...';
    log('首次使用：正在自动安装 FFmpeg。只需安装一次，请保持联网。');
    D('FFMPEG INSTALL START');
    const resp = await fetch(`${SERVICE}/ffmpeg-install`, { method: 'POST' });
    const result = await resp.json();
    if (!resp.ok || !result.ok) throw new Error(result.error || 'FFmpeg安装失败');
    D('FFMPEG INSTALL OK');
    return result;
  }

  async function offlineCompose() {
    if (state.composing) return;
    if (!state.videoSrc) {
      toast('请先导入贤者PV');
      return;
    }

    state.composing = true;
    const btn = $('#composeBtn');
    btn.classList.remove('compose-success');
    const span = btn.querySelector('span');
    const oldTime = pv.currentTime || 0;
    const requestedKey = compKey();
    if(window.bw7)window.bw7.composeStarted(requestedKey);
    btn.disabled = true;
    $('#playBtn').disabled = true;
    span.textContent = '合成中...';
    D('OFFLINE COMPOSE CLICK');

    try {
      await ensureFFmpeg(span);
      await document.fonts.ready;

      span.textContent = '合成中...';
      const profile = await buildProfilePng();
      const decoRect = state.decoSrc ? sceneRect(decoLayer) : null;
      const meta = {
        appearTime: Number($('#appearTime').value || 0),
        entryEffect: $('#entryEffect').value,
        profile: profile ? {
          cx: profile.cx,
          cy: profile.cy,
          w: profile.w,
          h: profile.h
        } : null,
        deco: decoRect ? {
          cx: decoRect.x + decoRect.w / 2,
          cy: decoRect.y + decoRect.h / 2,
          w: Math.max(1, Math.round(decoRect.w)),
          h: Math.max(1, Math.round(decoRect.h))
        } : null
      };

      const fd = new FormData();
      const videoBlob = state.videoBlob || await fetch(state.videoSrc).then(r => r.blob());
      fd.append('video', videoBlob, state.videoName || 'input.mp4');
      fd.append('meta', JSON.stringify(meta));
      if (profile) fd.append('profile', await markReveal(profile.blob), 'profile.png');
      if (decoRect) {
        const decoBlob = state.decoBlob || await fetch(state.decoSrc).then(r => r.blob());
        fd.append('deco', await markReveal(decoBlob), state.decoName || 'deco.png');
      }

      if(compKey()!==requestedKey)throw new Error('资料已更新，本次结果作废');
      span.textContent = '合成中...';
      log('V6.8.2 正在离线逐帧合成：不再使用 MediaRecorder 实时录制。');
      const response = await fetch(`${SERVICE}/compose`, { method: 'POST', body: fd });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || '离线合成失败');

      span.textContent = '合成中...';
      const fileResponse = await fetch(`${SERVICE}/compose-result?id=${encodeURIComponent(result.id)}`);
      if (!fileResponse.ok) throw new Error('读取质检成片失败');
      const blob = await fileResponse.blob();
      if (!blob.size) throw new Error('成片文件为空');
      if(compKey()!==requestedKey)throw new Error('资料已更新，本次结果作废');

      clearComposition();
      state.composedBlob = blob;
      state.composedSrc = URL.createObjectURL(blob);
      state.composedKey = requestedKey;
      if(window.bw7)window.bw7.composeReady(requestedKey);
      span.textContent = '已合成 ✓';
      btn.classList.add('compose-success');
      log(`离线合成通过质检：${result.frames}/${result.expectedFrames} 帧 · 60 FPS · 1920×1080 · ${(blob.size / 1048576).toFixed(1)} MB。`);
      toast('离线合成通过质检，可以播放');
      D(`OFFLINE COMPOSE OK ${result.frames}/${result.expectedFrames}`);
    } catch (e) {
      D('OFFLINE COMPOSE FAIL ' + (e && e.stack || e));
      clearComposition();
      btn.classList.remove('compose-success');
      span.textContent = '视频合成';
      if(window.bw7)window.bw7.composeFailed(requestedKey,e);
      log('离线合成失败：' + (e && e.message || e));
      if(compKey()!==requestedKey)log('已切换用户，正在准备最新资料');else toast('合成失败：' + (e && e.message || e));
    } finally {
      state.composing = false;
      if(window.bw7)window.bw7.composeEnded(requestedKey);
      btn.disabled = false;
      $('#playBtn').disabled = false;
      if (state.videoSrc && !state.playingComposed) {
        pv.pause();
        if (pv.src !== state.videoSrc) {
          pv.src = state.videoSrc;
          pv.load();
          try { await waitMeta(); } catch (_) {}
        }
        pv.currentTime = Math.min(oldTime, pv.duration || 0);
      }
      renderAll();
      sync();
    }
  }



  // V6.8.2 shell lifecycle + button-state polish.
  const shellStyle = document.createElement('style');
  shellStyle.textContent = `
    #composeBtn:disabled:not(.compose-success){opacity:1!important;background:#11303a!important;color:#dffcff!important;border:1px solid #28505d!important;box-shadow:none!important}
    #composeBtn.compose-success{opacity:1!important;background:#19f06f!important;color:#03180b!important;border:1px solid #74ffae!important;box-shadow:0 0 18px rgba(25,240,111,.42)!important}
  `;
  document.head.appendChild(shellStyle);

  window.bwComposeLayers={profile:buildProfilePng,mark:markReveal};if(window.BW_QUEUE_WORKER)return;
  const WATCHDOG = 'http://127.0.0.1:38559';
  let shellExitSent = false;
  const shellPost = (path) => {
    try { fetch(WATCHDOG + path, {method:'POST', mode:'no-cors', cache:'no-store', keepalive:true}).catch(()=>{}); } catch (_) {}
  };
  const shellExit = () => {
    if (shellExitSent) return;
    shellExitSent = true;
    try { navigator.sendBeacon(WATCHDOG + '/ui-exit', 'close'); } catch (_) {}
    shellPost('/ui-exit');
  };
  shellPost('/ui-alive');
  setInterval(() => shellPost('/ui-alive'), 1500);
  // Heartbeat expiry handles an actual close; reload must not kill the task queue.
  

  window.v680Compose = offlineCompose;
  const btn = $('#composeBtn');
  if (btn) btn.onclick = offlineCompose;
  D('V6.8 OFFLINE COMPOSITOR READY');
})();


(() => {
  'use strict';
  const PREF='beauty_weapon_v7_preferences',BRIDGE='http://127.0.0.1:38560';
  // A viewer is session data; template geometry and assets are durable settings.
  if(!window.BW_QUEUE_WORKER){const bootAt=Date.now(),originalRenderProfile=renderProfile;renderProfile=function(){if(state.profile&&state.profileTs<bootAt){state.profile=null;state.profileTs=0;}return originalRenderProfile();};if(startupState)startupState.manualName='';state.profile=null;state.profileTs=0;state.manualName='';nicknameInput.value='';state.locked=false;clearComposition();renderProfile();}
  let preferences={autoCompose:true,mode:'normal',randomTemplates:true};
  try{Object.assign(preferences,JSON.parse(localStorage.getItem(PREF)||'{}'));}catch{}
  const m={suspended:0,templateBusy:false,pollBusy:false,targetSource:'',readProblem:'',assetProblem:'',pending:null,failedKey:'',attemptKey:'',readyKey:'',timer:0,lastProfile:'',connected:false,lastSelection:0,playingUser:'',posterToken:0,started:false,playBusy:false,randomBusy:false,randomPreparedKey:'',randomProblem:'',randomTemplate:null,randomSkipped:[],randomFailedKey:''};
  const canonical=value=>{try{const u=new URL(value);return u.origin+u.pathname.replace(/\/$/,'');}catch{return '';}};
  const isProfile=value=>{try{const u=new URL(value);return u.protocol==='https:'&&(u.hostname==='douyin.com'||u.hostname.endsWith('.douyin.com'))&&/^\/user\/[^/]+\/?$/.test(u.pathname);}catch{return false;}};
  const signature=p=>JSON.stringify([p?.nickname||'',p?.avatarDataUrl||'',canonical(p?.sourceUrl||'')]);
  const blobs=new WeakMap();let nextBlob=1;
  const blobKey=b=>{if(!b)return null;if(!blobs.has(b))blobs.set(b,nextBlob++);return[blobs.get(b),b.size,b.type];};
  const rounded=o=>o&&Object.fromEntries(Object.entries(o).map(([k,v])=>[k,typeof v==='number'?Math.round(v*100000)/100000:v]));
  compKey=function(){const s=currentState();return JSON.stringify([blobKey(state.videoBlob),blobKey(state.fontBlob),blobKey(state.decoBlob),signature(state.profile),state.manualName.trim(),s.appearTime,s.entryEffect,s.textColor,rounded(s.profileNorm),rounded(s.decoNorm),s.fontSize,s.effectiveFontSize,preferences.randomTemplates?m.lastSelection:0]);};
  const originalSync=sync;
  sync=function(){originalSync();if(m.started&&!m.suspended){schedule();update();}};
  const style=document.createElement('style');
  style.textContent=`
  .topbar{gap:12px}.brand{min-width:0;font-size:21px}.brand span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bw7-mode{max-width:132px;flex-shrink:0}.top-status{max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .bw7-tools{display:flex;gap:6px;margin-top:7px;flex-wrap:wrap}.bw7-tools button{flex:1;font-size:11px;padding:6px}.bw7-status{padding:9px 11px;background:#08272d;border:1px solid #28636b;border-radius:10px;line-height:1.5;font-size:12px;margin:8px 0;color:#aaf6e7}.bw7-status.warn{border-color:#865f28;color:#ffd89a}.bw7-status.bad{border-color:#a84852;color:#ffb8bf}.bw7-auto{margin:8px 0;font-size:12px;color:#b3d6dc}.bw7-materials{margin-top:8px;padding-top:8px;border-top:1px solid #214049;font-size:11px;line-height:1.7;color:#9bbdc6}
  #bw7Live{display:none}.bw7-live .workspace{position:absolute;left:-12000px;top:52px;width:100vw;height:calc(100vh - 52px);pointer-events:none}.bw7-live #topStatus{display:none}.bw7-live .brand{font-size:18px}.bw7-live #bw7Live{position:fixed;inset:62px 12px 12px;display:flex;flex-direction:column;gap:10px;max-width:680px;margin:0 auto;background:#0b1b22;border:1px solid #284852;border-radius:16px;padding:14px;overflow:auto}
  .bw7-preview{position:relative;border:1px solid #244d58;border-radius:12px;background:#030c10;overflow:hidden;aspect-ratio:16/9;flex-shrink:0}.bw7-preview canvas{display:block;width:100%;height:100%;object-fit:contain}.bw7-preview-label{position:absolute;left:9px;top:9px;font-size:11px;border-radius:6px;padding:4px 7px;background:#061b21d9;color:#9debdc}.bw7-person{display:flex;gap:12px;align-items:center;min-height:68px}.bw7-person img{width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid #59d8bb;background:#102a33}.bw7-person strong{display:block;font-size:20px;word-break:break-all}.bw7-person small{display:block;font-size:12px;margin-top:5px;color:#9ebfc8}.bw7-live-status{font-size:14px;line-height:1.65;padding:10px 12px;border-radius:10px;background:#09282f;border:1px solid #2b6167;color:#b5eee3}.bw7-live-status.bad{border-color:#a84852;color:#ffbdc4}.bw7-live-status.warn{border-color:#8a632d;color:#ffd99d}#bw7LivePlay{min-height:54px;font-size:18px;background:#44dfb7;color:#06251e;flex-shrink:0}#bw7LivePlay:disabled{background:#173842;color:#91b2bc;opacity:1}.bw7-foot{font-size:11px;color:#8ab2bd;line-height:1.6;margin-top:0}
  @media(max-width:900px){.topbar .top-status{display:none}}`;
  document.head.appendChild(style);
  const brand=$('.brand');if(brand){const img=brand.querySelector('img');brand.replaceChildren();if(img)brand.append(img);const text=document.createElement('span');text.textContent='美丽武器 V8.1.7 | 直播回馈';brand.append(text);}
  document.title='美丽武器 V8.1.7  ｜直播回馈';
  const mode=document.createElement('button');mode.className='bw7-mode';mode.id='bw7Mode';mode.setAttribute('aria-label','工作模式');mode.type='button';mode.title='点击切换普通模式和直播模式';$('.topbar').append(mode);
  const live=document.createElement('section');live.id='bw7Live';live.innerHTML='<div class="bw7-preview"><canvas id="bw7Poster" width="640" height="360"></canvas><span class="bw7-preview-label">待播放成片 · 核对画面</span></div><div class="bw7-person"><img id="bw7Avatar" alt="已识别用户头像"><div><strong id="bw7Name">等待识别用户</strong><small id="bw7Identity">打开送礼用户的抖音主页</small></div></div><div id="bw7LiveStatus" class="bw7-live-status" role="status" aria-live="polite">等待头像和昵称</div><button id="bw7LivePlay" disabled>立即播放</button><button class="secondary" id="bw71LiveOutput">打开直播输出窗口</button><div class="bw7-foot">头像和完整昵称在这里独立显示。核对正确且合成完成后再播放。切回普通模式可调整模板和素材。</div>';
  document.body.append(live);
  const templateLabel=document.createElement('small');templateLabel.id='bw711Template';$('#bw7Identity').after(templateLabel);
  const ordinaryStatus=document.createElement('div');ordinaryStatus.id='bw7Status';ordinaryStatus.className='bw7-status';ordinaryStatus.setAttribute('role','status');$('.manual-card').insertBefore(ordinaryStatus,$('.manual-card').children[1]);
  const autoRow=document.createElement('label');autoRow.className='bw7-auto';autoRow.innerHTML='<input type="checkbox" id="bw7Auto"> 读取头像和昵称后自动合成';ordinaryStatus.after(autoRow);$('#bw7Auto').checked=preferences.autoCompose;
  const randomRow=document.createElement('label');randomRow.className='bw7-auto';randomRow.innerHTML='<input type="checkbox" id="bw711Random"> 随机使用所有未归档模板';autoRow.after(randomRow);$('#bw711Random').checked=preferences.randomTemplates;
  const toolRow=document.createElement('div');toolRow.className='bw7-tools';toolRow.innerHTML='<button class="secondary" id="bw7Export">导出模板＋素材</button><button class="secondary" id="bw7Import">导入模板包</button><button class="secondary" id="bw7RestoreArchive" title="恢复最近一次归档的模板">恢复归档</button>';$('#templateStatus').after(toolRow);
  const materials=document.createElement('div');materials.id='bw7Materials';materials.className='bw7-materials';toolRow.after(materials);
  const fileInput=document.createElement('input');fileInput.type='file';fileInput.accept='.bwtemplate';fileInput.hidden=true;document.body.append(fileInput);
  $('.manual-card').style.overflowY='auto';$('.right').style.overflowY='auto';
  function savePreferences(){if(window.BW_QUEUE_WORKER)return;localStorage.setItem(PREF,JSON.stringify(preferences));}
  function setMode(value){preferences.mode=value==='live'?'live':'normal';mode.textContent=preferences.mode==='live'?'切换普通模式':'切换直播模式';mode.setAttribute('aria-pressed',String(preferences.mode==='live'));document.body.classList.toggle('bw7-live',preferences.mode==='live');savePreferences();update();if(!window.BW_QUEUE_WORKER&&window.bw71Resize)window.bw71Resize(preferences.mode);}
  mode.onclick=()=>setMode(preferences.mode==='live'?'normal':'live');
  $('#bw7Auto').onchange=()=>{preferences.autoCompose=$('#bw7Auto').checked;savePreferences();m.failedKey='';schedule();update();};
  function setRandomTemplates(value){preferences.randomTemplates=!!value;savePreferences();m.randomPreparedKey='';m.randomProblem='';m.randomTemplate=null;m.randomSkipped=[];m.failedKey='';m.randomFailedKey='';clearComposition();clearPoster();schedule();update();}
  $('#bw711Random').onchange=()=>setRandomTemplates($('#bw711Random').checked);
  const randomIdentityKey=()=>JSON.stringify([m.lastSelection,signature(state.profile)]);
  const randomFailureKey=()=>randomIdentityKey()+'|'+(m.randomTemplate?.id||'');
  function complete(){return !!(state.profile?.nickname?.trim()&&state.profile?.avatarDataUrl&&isProfile(state.profile?.sourceUrl)&&avatarImg.src===state.profile.avatarDataUrl&&avatarImg.complete&&avatarImg.naturalWidth>0);}
  function timingProblem(){const appear=Number($('#appearTime').value),duration=pv.duration,entry={none:0,fade:.55,pop:.5,sweep:.7,revealLeft:1,revealRight:1}[$('#entryEffect').value]||0;if(!Number.isFinite(appear)||appear<0)return '出场时间无效，请回普通模式调整';if(Number.isFinite(duration)&&duration>0&&appear+entry+.05>=duration)return '视频结尾不足以完整显示用户信息，请回普通模式调早出场时间';return '';}
  avatarImg.addEventListener('load',()=>{if(complete()&&m.readProblem.startsWith('头像无法显示'))m.readProblem='';schedule();update();});
  avatarImg.addEventListener('error',()=>{if(state.profile?.avatarDataUrl){m.readProblem='头像无法显示，已停止自动合成；请在网页助手中重新读取';clearComposition();clearPoster();update();}});
  function readiness(){
    if(m.playBusy)return ['正在打开输出窗口…','warn'];
    if(!pv.paused&&state.playingComposed)return ['正在播放：'+(m.playingUser||state.profile?.nickname||'当前用户')+(m.pending?'；播完后准备下一位':'') ,'warn'];
    if(m.templateBusy)return ['正在载入模板和素材…','warn'];
    if(m.randomBusy)return ['正在随机选择可用模板…','warn'];
    if(preferences.randomTemplates&&m.randomProblem)return [m.randomProblem,'bad'];
    if(m.assetProblem)return [m.assetProblem,'bad'];
    if(m.readProblem)return [m.readProblem,'bad'];
    if(m.pending)return ['等待当前视频结束，再准备新用户','warn'];
    if(preferences.randomTemplates&&complete()&&m.randomPreparedKey!==randomIdentityKey())return ['已识别 '+state.profile.nickname+'，正在准备随机模板…','warn'];
    if(!state.videoBlob)return ['请切回普通模式，导入 PV 或加载完整模板','warn'];
    if(state.locked)return ['当前用户已锁定，请回普通模式解锁后使用自动直播流程','warn'];
    if(!state.autoReceive)return ['自动接收已关闭，请回普通模式开启后使用直播模式','warn'];
    if(timingProblem())return [timingProblem(),'bad'];
    if(state.manualName.trim())return ['手动昵称正在覆盖网页昵称；直播前请清空手动昵称','bad'];
    if(!complete())return [m.connected?'等待送礼用户的完整头像和昵称':'等待 V8.1.7 网页助手连接；请打开用户主页','warn'];
    if(state.composing)return [m.attemptKey!==compKey()?'已切换到 '+state.profile.nickname+'，正在准备最新用户…':'正在为 '+state.profile.nickname+' 合成，请稍候…','warn'];
    if(m.failedKey===compKey()||preferences.randomTemplates&&m.randomFailedKey===randomFailureKey())return ['合成失败，请切回普通模式点击“视频合成”重试','bad'];
    if(state.composedSrc&&state.composedKey===compKey())return ['可以播放：'+state.profile.nickname+(state.locked?'（当前用户已锁定）':''),''];
    return [preferences.autoCompose?'已识别 '+state.profile.nickname+'，正在准备合成…':'自动合成已关闭，请在普通模式手动合成','warn'];
  }
  function update(){
    if((window.bwQueueOwnsLive&&!window.bw817Fallback)&&window.bwQueueRefreshLive){window.bwQueueRefreshLive();return;}const [message,kind]=readiness();ordinaryStatus.textContent=message;ordinaryStatus.className='bw7-status '+kind;$('#bw7LiveStatus').textContent=message;$('#bw7LiveStatus').className='bw7-live-status '+kind;
    const p=m.pending?.profile||state.profile;$('#bw7Name').textContent=p?.nickname||'等待识别用户';if(window.bw71Avatar)window.bw71Avatar($('#bw7Avatar'),p?.avatarDataUrl||'');else $('#bw7Avatar').style.visibility='hidden';
    $('#bw7Identity').textContent=m.pending?'下一位待处理用户':p?'已读取完整昵称 · '+(state.locked?'用户已锁定':'请核对头像'):'打开送礼用户的抖音主页';
    const chosen=m.randomTemplate&&(m.randomPreparedKey===randomIdentityKey()||state.playingComposed)?m.randomTemplate.name:'';
    templateLabel.textContent=preferences.randomTemplates?(chosen?'本次模板：'+chosen+(m.randomSkipped.length?' · 跳过 '+m.randomSkipped.length+' 个不可用模板':''):'随机模板：等待选择'):'固定使用当前模板';templateLabel.title=m.randomSkipped.join('\n');
    $('#bw711Random').checked=preferences.randomTemplates;if($('#bw711RandomSetting'))$('#bw711RandomSetting').checked=preferences.randomTemplates;
    $('#bw7LivePlay').disabled=!!kind||state.composing||m.playBusy||!pv.paused;
    for(const id of ['playBtn','bw7LivePlay'])$('#'+id).classList.toggle('bw815-ready',!kind&&!state.composing&&!m.playBusy&&pv.paused&&state.composedKey===compKey()&&!!state.composedSrc);
    $('#bw7LivePlay').textContent=m.playBusy?'正在打开输出窗口…':(!pv.paused&&state.playingComposed?'播放中…':'立即播放');
    materials.textContent=['视频：'+(state.videoName||'未导入'),'字体：'+(state.fontName||'系统默认'),'图片：'+(state.decoName||'无图片')].join('　');
  }
  function schedule(delay=650){clearTimeout(m.timer);if(window.BW_QUEUE_WORKER||!m.started||m.suspended||!preferences.autoCompose)return;m.timer=setTimeout(maybeCompose,delay);}
  async function maybeCompose(){
    if((window.bwQueueOwnsLive&&!window.bw817Fallback)||m.suspended||m.templateBusy||m.randomBusy||m.readProblem||m.pending||state.composing||!pv.paused||!complete()||state.manualName.trim()||state.locked||!state.autoReceive)return;
    if(preferences.randomTemplates&&!await prepareRandomTemplate())return;
    if(preferences.randomTemplates&&m.randomFailedKey===randomFailureKey())return;
    if(m.assetProblem||!state.videoBlob||timingProblem())return;
    const key=compKey();if(state.composedKey===key&&state.composedSrc||m.failedKey===key)return;
    await compose(false);
  }
  const oldCompose=window.v680Compose;const originalCompose=async()=>{if(!window.bwQueueApi)return oldCompose();await window.bwQueueApi('manual',{action:'claim'});try{return await oldCompose();}finally{await window.bwQueueApi('manual',{action:'release'});}};
  async function compose(manual){
    if(m.suspended||m.templateBusy||m.randomBusy||state.composing)return;
    if(!pv.paused){toast('请等待当前视频播放结束，再准备下一条');return;}
    if(manual){m.failedKey='';m.randomFailedKey='';if(m.assetProblem&&state.videoBlob)m.assetProblem='';}
    if(m.readProblem&&!state.manualName.trim()){toast(m.readProblem);return;}
    if(preferences.randomTemplates&&complete()&&!state.manualName.trim()){if(manual&&m.randomProblem)m.randomPreparedKey='';if(!await prepareRandomTemplate())return;}
    if(timingProblem()){toast(timingProblem());return;}
    try{await originalCompose();}catch(e){toast(e.message);}update();
  }
  window.v680Compose=()=>compose(true);$('#composeBtn').onclick=window.v680Compose;
  async function makePoster(){
    if((window.bwQueueOwnsLive&&!window.bw817Fallback))return;
    const token=++m.posterToken,src=state.composedSrc,key=state.composedKey;if(!src)return;
    const video=document.createElement('video');video.muted=true;video.preload='auto';video.src=src;
    try{
      await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('预览读取超时')),12000);video.onloadedmetadata=()=>{clearTimeout(timer);resolve();};video.onerror=()=>{clearTimeout(timer);reject(Error('预览读取失败'));};});
      const point=Math.min(Math.max(0,video.duration-.1),Number($('#appearTime').value||0)+1.15);
      await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('预览定位超时')),12000);video.onseeked=()=>{clearTimeout(timer);resolve();};video.currentTime=Math.max(.001,point);});
      if(!(window.bwQueueOwnsLive&&!window.bw817Fallback)&&token===m.posterToken&&key===state.composedKey){$('#bw7Poster').getContext('2d').drawImage(video,0,0,640,360);}
    }catch(e){D('V7 POSTER '+e.message);}finally{video.pause();video.removeAttribute('src');video.load();}
  }
  const posterCtx=$('#bw7Poster').getContext('2d');
  function clearPoster(){m.posterToken++;if((window.bwQueueOwnsLive&&!window.bw817Fallback))return;posterCtx.fillStyle='#030c10';posterCtx.fillRect(0,0,640,360);posterCtx.fillStyle='#90b9c3';posterCtx.font='18px Microsoft YaHei';posterCtx.textAlign='center';posterCtx.fillText('合成完成后显示核对画面',320,180);}
  window.bw7={
    composeStarted(key){m.attemptKey=key;m.readyKey='';update();},
    composeReady(key){m.readyKey=key;m.failedKey='';m.randomFailedKey='';makePoster();},
    composeFailed(key,error){if(key===compKey())m.failedKey=key;else m.failedKey='';if(preferences.randomTemplates&&m.randomPreparedKey===randomIdentityKey())m.randomFailedKey=randomFailureKey();},
    composeEnded(key){setTimeout(()=>{update();if(compKey()!==key)schedule(100);},0);},
    setMode,setRandomTemplates,loadTemplateById:async id=>{ $('#templateSelect').value=id;return loadTemplate(); },
    exportTemplate:()=>exportTemplate(),importTemplate:blob=>importTemplate(blob),
    state:()=>({lastSelection:m.lastSelection,targetSource:m.targetSource,readProblem:m.readProblem,assetProblem:m.assetProblem,pending:!!m.pending,complete:complete(),ready:state.composedKey===compKey()&&!!state.composedSrc&&!m.randomProblem,templateBusy:m.templateBusy||m.randomBusy,randomTemplate:m.randomTemplate?{...m.randomTemplate}:null,randomSkipped:[...m.randomSkipped],randomProblem:m.randomProblem,randomPrepared:m.randomPreparedKey===randomIdentityKey(),randomFailed:m.randomFailedKey===randomFailureKey(),preferences:{...preferences}})
  };
  const originalPlay=doPlay;
  doPlay=async function(){
    if(m.templateBusy||m.randomBusy||m.randomProblem||m.pending||m.readProblem||m.assetProblem){toast(readiness()[0]);return;}
    if(preferences.mode==='live'){
      if(readiness()[1]||state.composedKey!==compKey()){toast(readiness()[0]);return;}
      m.playBusy=true;update();
      try{if(!state.nativeOutputActive)throw Error('请先点击“打开直播输出窗口”');if(!state.nativeOutputActive)throw Error('直播输出窗口未打开，请在普通模式重试');}
      catch(e){toast(e.message);return;}finally{m.playBusy=false;update();}
    }
    m.playingUser=state.profile?.nickname||state.manualName||'当前视频';await originalPlay();update();
  };
  $('#playBtn').onclick=()=>doPlay();$('#bw7LivePlay').onclick=()=>doPlay();$('#bw71LiveOutput').onclick=$('#openOutputBtn').onclick;
  function applyProfile(p){
    const sig=signature(p);if(sig===m.lastProfile&&state.profile)return;
    m.lastProfile=sig;state.manualName='';nicknameInput.value='';state.profile=p;state.profileTs=Date.now();m.readProblem='';m.failedKey='';clearComposition();clearPoster();renderProfile();schedule();update();
  }
  function incoming(p){if(!pv.paused&&state.playingComposed){if(signature(p)!==signature(state.profile))m.pending={profile:p};update();return;}applyProfile(p);}
  function flushPending(){if(m.pending&&pv.paused){const pending=m.pending;m.pending=null;if(pending.profile)applyProfile(pending.profile);else{state.profile=null;m.lastProfile='';m.readProblem=pending.message||'正在读取下一位用户';clearComposition();clearPoster();renderProfile();}}schedule();update();}
  pv.addEventListener('ended',()=>setTimeout(flushPending,80));pv.addEventListener('pause',()=>setTimeout(flushPending,80));pv.addEventListener('play',update);
  async function readBridge(){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),4000);try{const r=await fetch(BRIDGE+'/api/assistant-state?x='+Date.now(),{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error('助手服务不可用');return await r.json();}finally{clearTimeout(timer);}}
  window.bw7Poll=async function(){
    if(window.BW_QUEUE_WORKER||window.bwQueueActivePlaying||m.pollBusy)return;m.pollBusy=true;
    try{
      const d=await readBridge();m.connected=!!d.connected;
      $('#recvState').textContent=d.connected?'V8.1.7 网页助手已连接':'等待 V8.1.7 网页助手';$('#recvState').classList.toggle('off',!d.connected);$('#topStatus').textContent=d.connected?'V8.1.7 本地服务正常 · 助手已连接':'V8.1.7 服务正常 · 等待网页助手';
      if(!state.autoReceive||state.locked){update();return;}
      const s=d.status||{},source=canonical(s.sourceUrl);
      if(isProfile(s.sourceUrl)&&Number(d.selection)>m.lastSelection){m.lastSelection=Number(d.selection);if(state.manualName){state.manualName='';nicknameInput.value='';m.failedKey='';if(pv.paused){clearComposition();clearPoster();}renderProfile();schedule();}if(preferences.randomTemplates){if(pv.paused){clearComposition();clearPoster();}schedule();}}
      if(isProfile(s.sourceUrl)&&source!==m.targetSource){
        m.targetSource=source;m.failedKey='';state.manualName='';nicknameInput.value='';
        if(!pv.paused&&state.playingComposed)m.pending={message:'正在读取下一位用户'};
        else{state.profile=null;m.lastProfile='';m.readProblem='正在读取新用户的头像和昵称…';clearComposition();clearPoster();renderProfile();}
      }
      const latest=canonical(d.acceptedSource);
      if(isProfile(s.sourceUrl)&&source===m.targetSource&&s.status!=='ready'){
        const message=s.status==='loading'?'正在读取头像和昵称…':s.detail||'读取失败，请在网页助手中重新读取';
        if(!pv.paused&&state.playingComposed)m.pending={message};else m.readProblem=message;
      }else if(d.profile&&latest===m.targetSource&&(!isProfile(s.sourceUrl)||source===latest)&&(!isProfile(s.sourceUrl)||s.status==='ready')){
        if(d.profile.nickname&&d.profile.avatarDataUrl){m.readProblem='';incoming(d.profile);}else m.readProblem='头像下载失败，未准备可播放视频；请重新读取';
      }
      update();
    }catch(e){m.connected=false;$('#recvState').textContent='V8.1.7 助手服务未连接';$('#recvState').classList.add('off');update();}
    finally{m.pollBusy=false;}
  };
  const oldClear=$('#clearProfile').onclick;$('#clearProfile').onclick=()=>{oldClear();m.lastProfile='';m.targetSource='';m.readProblem='';m.pending=null;clearComposition();clearPoster();update();};
  const oldLock=$('#lockProfile').onclick;$('#lockProfile').onclick=()=>{oldLock();update();if(!state.locked)window.bw7Poll();};
  const originalSetVideo=setVideoBlob,originalSetFont=setFontBlob,originalSetDeco=setDecoBlob;
  setVideoBlob=function(...args){m.failedKey='';m.assetProblem='';const result=originalSetVideo(...args);clearPoster();schedule();return result;};
  setFontBlob=async function(...args){m.suspended++;try{return await originalSetFont(...args);}finally{m.suspended--;m.failedKey='';schedule();update();}};
  setDecoBlob=async function(...args){m.suspended++;try{return await originalSetDeco(...args);}finally{m.suspended--;m.failedKey='';schedule();update();}};
  function assetManifest(){return Object.fromEntries(['video','font','deco'].map(k=>[k,state[k+'Blob']?{name:state[k+'Name']||k,size:state[k+'Blob'].size,type:state[k+'Blob'].type}:null]));}
  async function backupCurrent(){const stamp='v7-recovery:'+Date.now()+':'+Math.random().toString(16).slice(2);for(const k of ['video','font','deco'])if(state[k+'Blob'])await idbPut(stamp+':'+k,state[k+'Blob']);await idbPut(stamp+':state',currentState());return stamp;}
  async function checkAsset(kind,blob){
    if(!blob)return;
    if(kind==='deco'){const bitmap=await createImageBitmap(blob);bitmap.close();}
    if(kind==='font'){const face=new FontFace('BW7_Validate_'+Date.now(),await blob.arrayBuffer());await face.load();}
    if(kind==='video'){const video=document.createElement('video'),src=URL.createObjectURL(blob);video.preload='metadata';video.src=src;try{await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('视频无法读取')),12000);video.onloadedmetadata=()=>{clearTimeout(timer);if(!Number.isFinite(video.duration)||!video.videoWidth)reject(Error('视频信息无效'));else resolve();};video.onerror=()=>{clearTimeout(timer);reject(Error('视频无法读取'));};});return {duration:video.duration,width:video.videoWidth,height:video.videoHeight};}finally{video.removeAttribute('src');video.load();URL.revokeObjectURL(src);}}
  }
  function clearAsset(kind){
    const src=state[kind+'Src'];if(src)URL.revokeObjectURL(src);state[kind+'Blob']=null;state[kind+'Src']='';state[kind+'Name']='';
    if(kind==='video'){pv.pause();pv.removeAttribute('src');pv.load();$('#videoTag').textContent='未导入 PV';}
    if(kind==='font'){if(window.BW_QUEUE_WORKER)for(const face of document.fonts)if(face.family===state.fontFamily)document.fonts.delete(face);state.fontFamily='';nameText.style.fontFamily='';$('#fontTag').textContent='系统默认字体';}
    if(kind==='deco'){decoImg.removeAttribute('src');state.decoAspect=1;state.decoBaseWidth=0;decoLayer.style.width='0px';decoLayer.style.height='0px';$('#decoTag').textContent='无透明图片';}
  }
  saveTemplate=async function(){
    if(m.templateBusy||state.composing){toast('请等待当前操作结束');return;}
    const a=templateIndex(),selected=a.find(t=>t.id===$('#templateSelect').value);let name=prompt('模板名称：',selected?.name||state.videoName.replace(/\.[^.]+$/,'')||'新模板');if(!name?.trim())return;name=name.trim();
    const old=a.find(t=>t.name===name)||selected,id=crypto.randomUUID();
    try{
      if(old){const stamp='v7-template-history:'+id+':'+Date.now();await idbPut(stamp+':manifest',old);for(const k of ['video','font','deco']){const b=await idbGet('tpl:'+id+':'+k);if(b)await idbPut(stamp+':'+k,b);}}
      for(const k of ['video','font','deco'])await idbPut('tpl:'+id+':'+k,state[k+'Blob']||null);
      const item={id,name,state:templateState(),assets:assetManifest(),formatVersion:7,updatedAt:Date.now()},index=old?a.findIndex(t=>t.id===old.id):-1;if(index<0)a.push(item);else a[index]=item;
      saveTemplateIndex(a);refreshTemplates(id);$('#templateStatus').textContent='已保存完整素材清单：'+name;toast('模板与素材已保存');
    }catch(e){toast('保存失败：'+e.message);}
  };
  loadTemplate=async function(options={}){
    const id=$('#templateSelect').value,item=templateIndex().find(t=>t.id===id);if(!item){toast('请先选择模板');return false;}
    if(!pv.paused){toast('请等待视频播放结束后切换模板');return false;}
    if(state.composing||m.templateBusy){toast('当前正在准备视频，请稍后再加载模板');return false;}
    const previous={blobs:['video','font','deco'].map(k=>state[k+'Blob']),names:['video','font','deco'].map(k=>state[k+'Name']),settings:currentState(),manualName:state.manualName};let changed=false;
    m.templateBusy=true;m.suspended++;clearComposition();clearPoster();update();
    try{
      const items=await Promise.all(['video','font','deco'].map(k=>idbGet('tpl:'+id+':'+k))),missing=[];
      ['video','font','deco'].forEach((k,i)=>{const expected=item.assets?!!item.assets[k]:(k==='video'||k==='font'&&!!item.state?.fontFamily||k==='deco'&&(item.state?.decoNorm?.w||0)>0);if(expected&&!items[i])missing.push({video:'PV 视频',font:'字体',deco:'透明图片'}[k]);});
      if(missing.length)throw Error('模板缺少 '+missing.join('、')+'；已停止加载，请重新导入素材或模板包');
      if(options.random&&!items[0])throw Error('模板没有 PV 视频');
      const checks=[];for(let i=0;i<3;i++)checks[i]=await checkAsset(['video','font','deco'][i],items[i]);
      if(options.random){const appear=Number(item.state?.appearTime),effect=item.state?.entryEffect,entry={none:0,fade:.55,pop:.5,sweep:.7,revealLeft:1,revealRight:1}[effect];if(!Number.isFinite(appear)||appear<0||entry===undefined||appear+entry+.05>=checks[0].duration)throw Error('模板出场时间不足以完整显示用户信息');}
      if(options.isCurrent&&!options.isCurrent())return false;
      if(!options.queue)await backupCurrent();
      changed=true;
      for(const k of ['video','font','deco'])clearAsset(k);
      const [v,f,d]=items;if(v)setVideoBlob(v,item.assets?.video?.name||v.name||'模板视频');if(f)await setFontBlob(f,item.assets?.font?.name||f.name||'模板字体');if(d)await setDecoBlob(d,item.assets?.deco?.name||d.name||'模板图片',{resetLayout:false});
      state.manualName='';nicknameInput.value='';applySaved(item.state,true);
      if(!options.queue)for(let i=0;i<3;i++)await idbPut(['video','font','deco'][i],items[i]||null);
      m.assetProblem='';m.failedKey='';$('#templateStatus').textContent='已加载：'+item.name+' · 仅使用本模板素材';if(!options.random)toast('模板已完整加载');return true;
    }catch(e){
      if(changed)try{for(const k of ['video','font','deco'])clearAsset(k);if(previous.blobs[0])setVideoBlob(previous.blobs[0],previous.names[0]);if(previous.blobs[1])await setFontBlob(previous.blobs[1],previous.names[1]);if(previous.blobs[2])await setDecoBlob(previous.blobs[2],previous.names[2],{resetLayout:false});state.manualName=previous.manualName;nicknameInput.value=previous.manualName;applySaved(previous.settings,true);if(!options.queue)for(let i=0;i<3;i++)await idbPut(['video','font','deco'][i],previous.blobs[i]||null);}catch(restoreError){D('V7 TEMPLATE RESTORE '+restoreError.message);}
      m.assetProblem=e.message;$('#templateStatus').textContent=e.message;if(!options.random)toast(e.message);return false;
    }
    finally{m.suspended--;m.templateBusy=false;schedule();update();}
  };
  function randomIndex(length){const sample=new Uint32Array(1),limit=4294967296-(4294967296%length);do{crypto.getRandomValues(sample);}while(sample[0]>=limit);return sample[0]%length;}
  async function prepareRandomTemplate(){
    const key=randomIdentityKey();if(m.randomPreparedKey===key)return !m.randomProblem;if(m.randomBusy)return false;
    m.randomBusy=true;m.randomProblem='';m.randomSkipped=[];m.randomFailedKey='';clearComposition();clearPoster();update();
    const current=()=>preferences.randomTemplates&&randomIdentityKey()===key&&pv.paused&&!m.pending&&!m.readProblem&&complete();
    try{
      const pool=[...templateIndex()];
      while(pool.length&&current()){
        const index=randomIndex(pool.length),item=pool[index];pool[index]=pool[pool.length-1];pool.pop();
        $('#templateSelect').value=item.id;m.assetProblem='';
        const loaded=await loadTemplate({random:true,isCurrent:current});
        if(!current())return false;
        if(loaded){m.randomTemplate={id:item.id,name:item.name};m.randomPreparedKey=key;m.randomProblem='';return true;}
        m.randomSkipped.push(item.name+'：'+(m.assetProblem||'模板已变化或无法加载'));
      }
      if(current()){m.randomPreparedKey=key;m.randomTemplate=null;m.assetProblem='';m.randomProblem=templateIndex().length?'所有模板均不可用，请检查素材和出场时间；本次停止合成':'没有可用模板，请先保存或导入模板；本次停止合成';}
      return false;
    }catch(e){if(current()){m.randomPreparedKey=key;m.randomTemplate=null;m.assetProblem='';m.randomProblem='随机模板准备失败：'+e.message+'；本次停止合成';}return false;}
    finally{m.randomBusy=false;update();if(preferences.randomTemplates&&randomIdentityKey()!==key)schedule(100);}
  }
  $('#saveTemplateBtn').onclick=saveTemplate;$('#loadTemplateBtn').onclick=loadTemplate;
  $('#deleteTemplateBtn').textContent='归档';$('#deleteTemplateBtn').onclick=async()=>{const id=$('#templateSelect').value,a=templateIndex(),item=a.find(t=>t.id===id);if(!item)return;if(!confirm('归档模板“'+item.name+'”？素材会保留，不删除文件。'))return;const archived=JSON.parse(localStorage.getItem(TEMPLATE_KEY+'_archived')||'[]');archived.push({...item,archivedAt:Date.now()});localStorage.setItem(TEMPLATE_KEY+'_archived',JSON.stringify(archived));saveTemplateIndex(a.filter(t=>t.id!==id));refreshTemplates();toast('模板已归档，素材仍保留');};
  $('#bw7RestoreArchive').onclick=()=>{try{const archived=JSON.parse(localStorage.getItem(TEMPLATE_KEY+'_archived')||'[]');if(!archived.length){toast('暂无归档模板');return;}const item=archived[archived.length-1],a=templateIndex();if(!a.some(t=>t.id===item.id)){if(a.some(t=>t.name===item.name))item.name+='（恢复）';a.push(item);saveTemplateIndex(a);}localStorage.setItem(TEMPLATE_KEY+'_archived',JSON.stringify(archived.slice(0,-1)));refreshTemplates(item.id);toast('已恢复归档：'+item.name);}catch(e){toast('恢复失败：'+e.message);}};
  async function digest(blob){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer()))].map(x=>x.toString(16).padStart(2,'0')).join('');}
  async function exportTemplate(){
    const item=templateIndex().find(t=>t.id===$('#templateSelect').value);if(!item)throw Error('请先选择一个模板');
    const files=[],parts=[];let offset=0;
    for(const k of ['video','font','deco']){const blob=await idbGet('tpl:'+item.id+':'+k);if(!blob){if(item.assets?.[k]||!item.assets&&(k==='video'||k==='font'&&item.state?.fontFamily||k==='deco'&&(item.state?.decoNorm?.w||0)>0))throw Error('模板素材缺失，无法导出完整模板包');continue;}files.push({kind:k,name:item.assets?.[k]?.name||blob.name||k,type:blob.type,size:blob.size,offset,sha256:await digest(blob)});parts.push(blob);offset+=blob.size;}
    const manifest={format:'BeautyWeaponTemplate',version:7,name:item.name,state:item.state,assets:item.assets||Object.fromEntries(files.map(f=>[f.kind,{name:f.name,size:f.size,type:f.type}])),files};
    const encoded=new TextEncoder().encode(JSON.stringify(manifest)),length=new Uint8Array(4);new DataView(length.buffer).setUint32(0,encoded.length,true);
    return {blob:new Blob([new TextEncoder().encode('BWTP7\r\n'),length,encoded,...parts],{type:'application/octet-stream'}),filename:item.name.replace(/[<>:"/\\|?*\x00-\x1f]/g,'_')+'.bwtemplate'};
  }
  function validateSettings(s){
    if(!s||typeof s!=='object'||Array.isArray(s))throw Error('模板设置无效');
    const t={appearTime:Number(s.appearTime),entryEffect:s.entryEffect,fontSize:Number(s.fontSize),textColor:s.textColor,decoScale:Number(s.decoScale)||100};
    if(!Number.isFinite(t.appearTime)||t.appearTime<0||t.appearTime>86400||!['none','fade','pop','sweep','revealLeft','revealRight'].includes(t.entryEffect)||!Number.isFinite(t.fontSize)||t.fontSize<1||t.fontSize>1000||!/^#[0-9a-f]{6}$/i.test(t.textColor))throw Error('模板参数超出允许范围');
    for(const key of ['profileNorm','decoNorm']){const r=s[key];if(r){if(!['x','y','w','h'].every(k=>Number.isFinite(r[k])&&Math.abs(r[k])<=100)||r.w<0||r.h<0)throw Error('模板布局无效');t[key]={x:r.x,y:r.y,w:r.w,h:r.h};}}
    return t;
  }
  async function importTemplate(blob){
    if(blob.size<11||blob.size>2147483648)throw Error('模板包大小无效');
    const start=new Uint8Array(await blob.slice(0,11).arrayBuffer());if(new TextDecoder().decode(start.slice(0,7))!=='BWTP7\r\n')throw Error('不是 V7 模板包');
    const size=new DataView(start.buffer).getUint32(7,true);if(!size||size>524288||11+size>blob.size)throw Error('模板包清单损坏');
    const manifest=JSON.parse(await blob.slice(11,11+size).text());if(manifest.format!=='BeautyWeaponTemplate'||manifest.version!==7||!Array.isArray(manifest.files)||manifest.files.length>3||typeof manifest.name!=='string'||!manifest.name.trim()||manifest.name.length>160)throw Error('模板包格式无效');
    const settings=validateSettings(manifest.state),files={},seen=new Set();let end=0;
    for(const info of manifest.files){if(!['video','font','deco'].includes(info.kind)||seen.has(info.kind)||!Number.isSafeInteger(info.size)||info.size<1||!Number.isSafeInteger(info.offset)||info.offset!==end||typeof info.name!=='string'||info.name.length>512||!/^\w{64}$/.test(info.sha256))throw Error('模板素材清单无效');seen.add(info.kind);end+=info.size;if(11+size+end>blob.size)throw Error('模板包素材被截断');const asset=new File([blob.slice(11+size+info.offset,11+size+end)],info.name,{type:typeof info.type==='string'?info.type:''});if(await digest(asset)!==info.sha256)throw Error('素材校验失败：'+info.name);await checkAsset(info.kind,asset);files[info.kind]=asset;}
    if(11+size+end!==blob.size)throw Error('模板包含有未声明的数据');
    const id=crypto.randomUUID(),a=templateIndex();let name=manifest.name.trim();if(a.some(t=>t.name===name))name+='（导入 '+new Date().toLocaleTimeString()+ '）';
    const assets={};for(const k of ['video','font','deco']){assets[k]=files[k]?{name:files[k].name,size:files[k].size,type:files[k].type}:null;await idbPut('tpl:'+id+':'+k,files[k]||null);}
    const item={id,name,state:settings,assets,formatVersion:7,updatedAt:Date.now()};a.push(item);saveTemplateIndex(a);refreshTemplates(id);$('#templateStatus').textContent='已导入：'+name+' · 点击“加载模板”应用';return item;
  }
  $('#bw7Export').onclick=async()=>{try{const result=await exportTemplate(),a=document.createElement('a'),url=URL.createObjectURL(result.blob);a.href=url;a.download=result.filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),15000);toast('模板与素材已导出');}catch(e){toast(e.message);}};
  $('#bw7Import').onclick=()=>fileInput.click();fileInput.onchange=async()=>{const file=fileInput.files[0];if(!file)return;$('#bw7Import').disabled=true;try{await importTemplate(file);toast('模板包校验通过并已导入');}catch(e){toast('导入失败：'+e.message);}finally{$('#bw7Import').disabled=false;fileInput.value='';}};
  window.bwQueueTemplates={index:templateIndex,load:async id=>{refreshTemplates(id);$('#templateSelect').value=id;return loadTemplate({queue:true,random:true});},error:()=>m.assetProblem};clearPoster();setMode(window.BW_QUEUE_WORKER?'normal':preferences.mode);m.started=!window.BW_QUEUE_WORKER;setTimeout(()=>{schedule();window.bw7Poll();update();},900);
})();


(() => {
  'use strict';if(window.BW_QUEUE_WORKER)return;
  const endpoint='http://127.0.0.1:38560';
  const placeholder='data:image/svg+xml;charset=utf-8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" rx="40" fill="#12343e"/><text x="40" y="57" text-anchor="middle" font-family="Microsoft YaHei,Arial" font-size="52" font-weight="bold" fill="#d3ecee">?</text></svg>');
  const avatarTokens=new WeakMap();
  window.bw71Avatar=(img,source)=>{
    const wanted=source||placeholder,previous=avatarTokens.get(img);if(previous?.wanted===wanted){const display=previous.good?source:placeholder;if(img.src!==display)img.src=display;return;}const record={wanted,good:false};avatarTokens.set(img,record);
    img.style.visibility='visible';img.src=placeholder;img.alt=source?'正在读取用户头像':'等待识别用户';
    if(!source)return;
    const probe=new Image();probe.onload=()=>{if(avatarTokens.get(img)===record&&probe.naturalWidth>0){record.good=true;img.src=source;img.alt='已识别用户头像';}};probe.onerror=()=>{if(avatarTokens.get(img)===record){img.src=placeholder;img.alt='头像未读取成功';}};probe.src=source;
  };
  const renderOld=renderProfile;
  renderProfile=function(...args){renderOld(...args);window.bw71Avatar($('#resultAvatar'),state.profile?.avatarDataUrl||'');};
  renderProfile();window.bw71Avatar($('#bw7Avatar'),state.profile?.avatarDataUrl||'');
  const style=document.createElement('style');style.textContent=`
  #recvState.off{background:#292619;border-color:#766322;color:#ffe068}.bw7-mode{max-width:140px;white-space:nowrap;font-size:12px}#bw71Settings{flex-shrink:0;padding:8px 12px;width:auto;font-size:12px}.bw7-live .brand{font-size:17px}.bw7-live .topbar{gap:8px}.bw7-live #bw7Live{gap:8px;padding:12px}.bw7-live .bw7-preview{max-height:270px;min-height:160px;flex-shrink:1}.bw7-live .bw7-person{min-height:60px}.bw7-live .bw7-person img{width:52px;height:52px}.bw7-live .bw7-person strong{font-size:18px}.bw7-live .bw7-live-status{font-size:12px;padding:8px 10px}.bw7-live #bw7LivePlay{min-height:46px;font-size:17px}.bw7-live #bw71LiveOutput{min-height:40px;font-size:13px;flex-shrink:0}.bw7-foot{font-size:10px;line-height:1.5}
  #bw71Dialog{width:min(540px,calc(100vw - 28px));max-height:calc(100vh - 28px);overflow:auto;border:1px solid #35616d;border-radius:16px;background:#0b1d25;color:#d6edf0;padding:20px;box-sizing:border-box}#bw71Dialog::backdrop{background:#020b10b8}.bw71-dialog-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:16px}.bw71-dialog-head strong{font-size:18px}.bw71-dialog-head button{width:auto;padding:5px 12px}.bw71-field{display:flex;flex-direction:column;gap:6px;font-size:12px;margin:12px 0}.bw71-field input,.bw71-field select{width:100%;box-sizing:border-box}.bw71-inline{display:flex;gap:6px}.bw71-inline input{min-width:0}.bw71-inline button{width:auto;flex-shrink:0;padding:7px 11px}.bw71-update-status{padding:12px;border-radius:10px;background:#102e37;font-size:12px;line-height:1.6;word-break:break-word;margin:12px 0}#bw71Progress{width:100%;accent-color:#41deb6}#bw71UpdateNotes{white-space:pre-wrap;font-size:12px;line-height:1.6;color:#adcbd1}.bw71-actions{display:flex;gap:8px}.bw71-actions button{flex:1}.bw71-note{font-size:11px;color:#94b7c0;line-height:1.6;margin-top:12px}#bw71Dialog summary{font-size:12px;cursor:pointer;color:#bce5ec}.bw71-source{font-size:11px;word-break:break-all;line-height:1.6}
  @media(max-width:620px){.bw7-live .brand span{max-width:180px;font-size:14px}.bw7-live .brand img{width:28px;height:28px}.bw7-live .topbar{padding:8px}.bw7-mode{font-size:11px;padding:7px}.bw7-live #bw7Live{inset:60px 8px 8px}}`;
  document.head.append(style);
  const button=document.createElement('button');button.id='bw71Settings';button.className='secondary';button.textContent='设置';$('#bw7Mode').before(button);
  const dialog=document.createElement('dialog');dialog.id='bw71Dialog';dialog.innerHTML=`<div class="bw71-dialog-head"><strong>设置 · 美丽武器 V8.1.7</strong><button class="secondary" id="bw71Close">关闭</button></div><div class="bw71-field"><label for="bw71Downloader">更新下载方式</label><select id="bw71Downloader"><option value="builtin">内置下载器</option><option value="ndm">本机 NDM 下载</option></select></div><details id="bw71NdmDetails"><summary>NDM 连接与下载目录</summary><label class="bw71-field">NDM 程序<div class="bw71-inline"><input id="bw71NdmPath" placeholder="自动发现正在运行的 NDM"><button id="bw71ChooseExe" class="secondary">选择</button></div></label><label class="bw71-field">NDM 实际下载目录<div class="bw71-inline"><input id="bw71NdmFolder"><button id="bw71ChooseFolder" class="secondary">选择</button></div></label><button id="bw71NdmTest" class="secondary">测试 NDM 连接</button><p class="bw71-note">目录须与 NDM 下载设置一致。配置跨版本保留，每次下载重新连接；下载结果必须通过大小与 SHA-256 校验。NDM 无法完成时会自动使用内置下载器，保留原文件。</p></details><details><summary>更新源</summary><label class="bw71-field">GitHub 更新清单<input id="bw71Source" spellcheck="false"></label><div class="bw71-source">仓库：1196197579-a11y / BeautyWeapon</div></details><div id="bw71UpdateStatus" class="bw71-update-status" role="status" aria-live="polite">正在读取设置…</div><progress id="bw71Progress" max="100" value="0"></progress><div id="bw71UpdateNotes"></div><div class="bw71-actions"><button id="bw71Check" class="primary">检查更新</button><button id="bw71Cancel" class="secondary" disabled>取消更新</button></div><p class="bw71-note">检查到新版后自动下载、校验并安装到独立目录。播放或合成结束后自动切换；旧版本、素材和下载包保留。浏览器扩展更新需要在浏览器中重新选择新版助手文件夹。</p>`;
  document.body.append(dialog);
  dialog.querySelector(':scope > .bw71-note:last-child').textContent='程序更新保留旧版、素材和队列。本次修复必须在 Edge 加载 V8.1.7 网页助手，禁用旧助手并刷新直播平台页面；只更新 EXE 不会更新浏览器中的助手。';
  const helperButton=document.createElement('button');helperButton.id='bw811HelperFolder';helperButton.className='secondary';helperButton.textContent='打开新版网页助手文件夹';dialog.querySelector(':scope > .bw71-note:last-child').before(helperButton);helperButton.onclick=()=>api('/api/app/helper-folder',{}).catch(e=>toast(e.message));
  const randomSetting=document.createElement('label');randomSetting.className='bw7-auto';randomSetting.innerHTML='<input id="bw711RandomSetting" type="checkbox"> 读取用户后随机使用所有未归档模板';dialog.querySelector('.bw71-field').before(randomSetting);randomSetting.querySelector('input').checked=window.bw7.state().preferences.randomTemplates;randomSetting.querySelector('input').onchange=()=>window.bw7.setRandomTemplates(randomSetting.querySelector('input').checked);
  let session='',config=null,configPromise=null,resizeSerial=0,requestedMode='',downloadRequested=false,restarting=false,lastPhase='',polling=false;
  async function api(path,data){
    const headers={};if(data!==undefined){await getConfig();headers['Content-Type']='application/json';headers['X-BW-Session']=session;}
    const response=await fetch(endpoint+path,{method:data===undefined?'GET':'POST',headers,body:data===undefined?undefined:JSON.stringify(data),cache:'no-store'});const result=await response.json();if(!response.ok||result.ok===false)throw Error(result.error||result.message||'本地设置服务不可用');return result;
  }
  async function getConfig(force=false){
    if(config&&!force)return config;
    if(configPromise)return configPromise;
    configPromise=(async()=>{const response=await fetch(endpoint+'/api/app/settings',{cache:'no-store'});const result=await response.json();if(!response.ok||!result.ok)throw Error(result.error||'设置服务未连接');session=result.session;config=result.settings;return config;})();
    try{return await configPromise;}finally{configPromise=null;}
  }
  window.bw71Resize=async value=>{
    requestedMode=value;const serial=++resizeSerial;
    for(let i=0;i<15;i++){if(serial!==resizeSerial)return;try{await api('/api/app/window-mode',{mode:value});return;}catch(e){if(i===14){toast('窗口未能自动调整，可手动调整：'+e.message);return;}await new Promise(resolve=>setTimeout(resolve,600));}}
  };
  function fill(c){$('#bw71Downloader').value=c.downloader;$('#bw71NdmPath').value=c.ndmPath||'';$('#bw71NdmFolder').value=c.ndmFolder||'';$('#bw71Source').value=c.source;$('#bw71NdmDetails').open=c.downloader==='ndm';}
  async function save(){const result=await api('/api/app/settings',{source:$('#bw71Source').value.trim(),downloader:$('#bw71Downloader').value,ndmPath:$('#bw71NdmPath').value.trim(),ndmFolder:$('#bw71NdmFolder').value.trim()});config=result.settings;return config;}
  function message(text){$('#bw71UpdateStatus').textContent=text;}
  button.onclick=async()=>{dialog.showModal();try{fill(await getConfig(true));await pollUpdate();}catch(e){message(e.message);}};
  $('#bw71Close').onclick=()=>dialog.close();dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
  $('#bw71Downloader').onchange=async()=>{$('#bw71NdmDetails').open=$('#bw71Downloader').value==='ndm';try{await save();message('下载方式已保存');}catch(e){message(e.message);}};
  for(const id of ['bw71NdmPath','bw71NdmFolder','bw71Source'])$('#'+id).onchange=async()=>{try{await save();message('设置已保存，后续版本继续使用');}catch(e){message(e.message);}};
  async function choose(kind,id){try{const result=await api('/api/app/choose-ndm',{kind});if(result.path){$('#'+id).value=result.path;await save();message('NDM 设置已保存');}}catch(e){message(e.message);}}
  $('#bw71ChooseExe').onclick=()=>choose('exe','bw71NdmPath');$('#bw71ChooseFolder').onclick=()=>choose('folder','bw71NdmFolder');
  $('#bw71NdmTest').onclick=async()=>{message('正在测试 NDM…');try{await save();const result=await api('/api/update/ndm-test',{});message(result.message);}catch(e){message(e.message);}};
  $('#bw71Check').onclick=async()=>{downloadRequested=false;restarting=false;message('正在检查更新…');try{await save();await api('/api/update/check',{});await pollUpdate();}catch(e){message(e.message);}};
  $('#bw71Cancel').onclick=async()=>{try{await api('/api/update/cancel',{});message('正在取消，已下载文件保留');}catch(e){message(e.message);}};
  async function pollUpdate(){
    if(polling)return;polling=true;
    try{
      const result=await api('/api/update/state');const phase=result.phase;
      const active=['checking','downloading','ndm','verifying','installing','restarting'].includes(phase)||result.busy;
      $('#bw71Check').disabled=active;$('#bw71Cancel').disabled=!active||phase==='restarting';$('#bw71Progress').value=result.progress||0;$('#bw71UpdateNotes').textContent=result.notes||'';
      const idle=!window.bwQueueWorking&&!window.bwQueueActivePlaying&&pv.paused&&!state.composing&&!window.bw7.state().templateBusy;
      if(phase==='ready'&&!idle)message('更新已安装，等待当前播放、合成或模板载入结束后切换；旧版保留');else message(result.message||'尚未检查更新');
      if(phase==='available'&&!result.busy&&!downloadRequested){downloadRequested=true;try{await api('/api/update/download',{});}catch(e){downloadRequested=false;message(e.message);}}
      if(phase==='ready'&&!result.busy&&!restarting&&idle){restarting=true;toast('更新已完成，正在切换新版；旧版保留');try{await api('/api/update/restart',{});}catch(e){restarting=false;message(e.message);}}
      if(phase==='error'&&phase!==lastPhase)toast('更新未完成：'+result.message);
      lastPhase=phase;
    }catch(e){if(dialog.open&&!restarting)message(e.message);}finally{polling=false;}
  }
  async function upload(url,body,headers){await getConfig();const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);try{const response=await fetch(url,{method:'POST',headers:{...headers,'X-BW-Session':session},body,signal:controller.signal});const result=await response.json();if(!response.ok||!result.ok)throw Error(result.error||'任务素材写入失败');return result;}finally{clearTimeout(timer);}}
  window.bw71={placeholder,settings:()=>getConfig(true),api,pollUpdate,upload};
  getConfig().then(()=>window.bw71Resize(document.body.classList.contains('bw7-live')?'live':'normal')).catch(()=>window.bw71Resize(document.body.classList.contains('bw7-live')?'live':'normal'));
  setInterval(pollUpdate,1500);
})();

(()=>{
 'use strict';if(window.BW_QUEUE_WORKER)return;
 const css=document.createElement('style');css.textContent=`
 .topbar{justify-content:flex-start;gap:12px}.topbar>.brand{margin-right:auto;min-width:0}.bw81-header-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex:0 1 auto;min-width:0;margin-left:auto}.bw81-header-actions #topStatus{display:inline-flex;margin:0;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}.bw81-header-actions #bw71Settings,.bw81-header-actions #bw7Mode{margin:0;flex-shrink:0}
 .left{overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin}.left>.card{flex-shrink:0}.bw81-template-card .template-row{grid-template-columns:minmax(0,1fr) auto}.bw81-template-card .bw7-tools{gap:5px}.bw81-template-card .bw7-tools button{padding:6px 4px;font-size:10px;white-space:nowrap}.bw81-template-card .bw7-materials{word-break:break-word}.right{display:flex;flex-direction:column;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin}.right>.card,.right>.bw8-panel{flex-shrink:0}.right>.manual-card{flex:1 0 auto}
 .bw7-live .bw81-header-actions{gap:6px}.bw7-live .bw81-header-actions #topStatus{display:inline-flex;max-width:140px;font-size:10px;padding:5px 7px}.bw7-live .topbar>.brand{flex:1 1 auto;overflow:hidden}.bw7-live .brand span{min-width:0}.bw7-live .bw81-header-actions #bw71Settings{padding:7px 9px}
 @media(max-width:640px){.bw81-header-actions{gap:5px}.bw81-header-actions #topStatus{max-width:110px!important;font-size:9px!important}.bw7-live .brand span{max-width:150px}.bw7-live .bw81-header-actions #bw7Mode{font-size:10px;padding:7px}}
 `;document.head.append(css);
 for(const b of document.querySelectorAll('.left button')){if(b.textContent.trim()==='导入贤者PV')b.textContent='导入视频';else if(b.textContent.trim()==='导入透明底图片')b.textContent='导入图片';}
 const outputStyle=getComputedStyle(document.getElementById('openOutputBtn'));Object.assign(document.getElementById('bw71LiveOutput').style,{background:outputStyle.backgroundColor,color:outputStyle.color,borderColor:outputStyle.borderColor});
 const bar=document.querySelector('.topbar'),group=document.createElement('div');group.className='bw81-header-actions';group.id='bw81HeaderActions';
 for(const id of ['topStatus','bw71Settings','bw7Mode']){const e=document.getElementById(id);if(e)group.append(e);}bar.append(group);
 const status=document.getElementById('topStatus');const describe=()=>status.title=status.textContent;describe();new MutationObserver(describe).observe(status,{childList:true,subtree:true,characterData:true});
 const select=document.getElementById('templateSelect'),row=select.closest('.template-row'),manual=row.closest('.manual-card'),left=document.querySelector('.left'),panel=document.createElement('section');panel.id='bw81Templates';panel.className='card bw81-template-card';const heading=document.createElement('h3');heading.textContent='模板与素材';panel.append(heading);
 const separator=row.previousElementSibling;if(separator?.classList.contains('hr'))separator.remove();
 const templateStatus=document.getElementById('templateStatus');const controls=[row,row.nextElementSibling,templateStatus,document.querySelector('.bw7-tools'),document.querySelector('.bw7-materials')];
 for(const e of controls)if(e)panel.append(e);left.children[0].after(panel);manual.querySelector('h3').textContent='手动昵称 + 输出';
})();

(()=>{
 'use strict';
 if(window.BW_QUEUE_WORKER){
  window.bwQueueRender=async task=>{
   await window.bwStartupReady;
   state.profile=structuredClone(task.profile);state.profileTs=Date.now();state.manualName='';nicknameInput.value='';renderProfile();await avatarImg.decode();
   const pool=task.templateId?window.bwQueueTemplates.index().filter(x=>x.id===task.templateId):[...window.bwQueueTemplates.index()];let chosen=null;const failures=[];
   while(pool.length){let i=0;if(!task.templateId){const a=new Uint32Array(1),limit=4294967296-4294967296%pool.length;do{crypto.getRandomValues(a);}while(a[0]>=limit);i=a[0]%pool.length;}const item=pool.splice(i,1)[0],size=item.state?.stageSize;stage.style.width=size?.w>0&&size.w<4096?size.w+'px':'';stage.style.height=size?.h>0&&size.h<2160?size.h+'px':'';if(await window.bwQueueTemplates.load(item.id)){chosen=item;break;}failures.push(item.name+'：'+window.bwQueueTemplates.error());}
   if(!chosen)throw Error('没有可用的完整模板。'+failures.join('；'));
   renderProfile();await document.fonts.ready;await avatarImg.decode();const p=await window.bwComposeLayers.profile();if(!p||!state.profile?.avatarDataUrl||state.profile.identityId!==task.expectedId)throw Error('头像昵称图层身份绑定失效');
   const dr=state.decoSrc?sceneRect(decoLayer):null;
   return {templateId:chosen.id,templateName:chosen.name,meta:{identityId:task.expectedId,templateId:chosen.id,appearTime:Number($('#appearTime').value),entryEffect:$('#entryEffect').value,profile:{cx:p.cx,cy:p.cy,w:p.w,h:p.h},deco:dr?{cx:dr.x+dr.w/2,cy:dr.y+dr.h/2,w:Math.round(dr.w),h:Math.round(dr.h)}:null},video:state.videoBlob,profile:await window.bwComposeLayers.mark(p.blob),deco:dr?await window.bwComposeLayers.mark(state.decoBlob):null};
  };return;
 }
 const API='http://127.0.0.1:38560/api/queue/',owner=crypto.randomUUID().replaceAll('-','');let snapshot=null,pollBusy=false,renderBusy=false,playing=null,posterId='',posterGeneration=0,worker=null,workerHtml='',workerUses=0,workerTouched=0,playBusy=false;
 // Native output reads video pixels; cross-port queue video must use CORS mode.
 pv.crossOrigin='anonymous';
 const names={pending:'待识别',resolving:'验证中',verified:'已验证',composing:'合成中',ready:'待播放',playing:'播放中',failed:'异常待处理'};
 async function request(action,data){const result=await window.bw71.api('/api/queue/'+action,data);if(result.ok===false)throw Error(result.error||'任务服务异常');return result;}
 window.bwQueueApi=request;
 const style=document.createElement('style');style.textContent=`#playBtn.bw815-ready,#bw7LivePlay.bw815-ready{background:#19f06f!important;color:#03180b!important;border-color:#74ffae!important;box-shadow:0 0 12px #19f06f55!important}#bw815QueueSettings button{width:auto;margin:6px 6px 0 0;padding:7px 10px} .bw8-panel{padding:10px;border:1px solid #29525d;border-radius:12px;background:#0a2029;margin-bottom:8px;font-size:12px;line-height:1.6}.bw8-head{display:flex;gap:8px;align-items:center;justify-content:space-between}.bw8-head strong{font-size:14px}.bw8-panel label{display:flex;gap:6px;align-items:center}.bw8-panel input{width:auto}.bw8-info{color:#a9c9d1;white-space:pre-wrap;margin:7px 0}.bw8-list{max-height:200px;overflow:auto}.bw8-task{border-top:1px solid #254650;padding:7px 0}.bw8-task strong{color:#dffcf2}.bw8-task small{display:block;color:#a7c3cc;word-break:break-word}.bw8-task button{width:auto;padding:4px 8px;margin-right:6px;font-size:11px}.bw8-error{color:#ffd67a}.bw8-count{color:#80efc9;font-size:12px}.bw8-live-count{display:block;font-size:12px;color:#83edcb}.bw8-panel button{margin-top:5px}.bw7-live .bw7-foot{max-height:55px;overflow:auto}#bw8RetryDialog{background:#0b2029;color:#def2f4;border:1px solid #38606c;border-radius:12px;padding:18px;width:min(500px,90vw)}#bw8RetryDialog input{width:100%;box-sizing:border-box}#bw8RetryDialog small{display:block;margin:10px 0;line-height:1.6}`;document.head.append(style);
 const panel=document.createElement('section');panel.className='bw8-panel';panel.innerHTML='<div class="bw8-head"><strong>送礼监听与制片队列</strong><label><input id="bw8Enabled" type="checkbox">自动监听</label></div><div id="bw8Info" class="bw8-info">正在连接任务服务…</div><div id="bw8Stats" class="bw8-count"></div><div id="bw8List" class="bw8-list"></div><small id="bw8Notice" class="bw8-error"></small>';$('.right').prepend(panel);
 const queueSettings=document.createElement('details');queueSettings.id='bw815QueueSettings';queueSettings.innerHTML='<summary>场次、历史任务与诊断</summary><p class="bw71-note">每次启动自动开启干净的新场次。旧计数、警告与任务留在历史记录，未播视频可恢复。清空头像/昵称只影响手动操作；停止队列任务请用任务下方的“停止任务”。</p><button id="bw8NewStream" class="secondary">归档当前场次并清空面板</button><button id="bw815HistoryRefresh" class="secondary">查看历史任务</button><div id="bw815History" class="bw8-list"></div>';$('#bw71Dialog').append(queueSettings);
 const count=document.createElement('small');count.className='bw8-live-count';$('#bw7LiveStatus').after(count);$('.bw7-foot').textContent='队列模式：只需点击播放。异常任务在普通模式处理。请保持 Edge 礼物明细展开，并将 anchor.douyin.com 加入始终活动网站。';
 const correction=document.createElement('dialog');correction.id='bw8RetryDialog';correction.innerHTML='<strong>人工核对送礼身份</strong><small id="bw8CorrectionInfo"></small><label>从原始礼物记录核对后粘贴用户主页地址<input id="bw8CorrectionUrl" placeholder="https://www.douyin.com/user/…"></label><small>这会记录人工纠正标记，重新读取并验证主页；系统不会凭昵称猜账号。</small><button id="bw8CorrectionConfirm">确认身份并重试</button><button id="bw8CorrectionCancel" class="secondary">取消</button>';document.body.append(correction);$('#bw8CorrectionCancel').onclick=()=>correction.close();let correcting='';
 $('#bw8CorrectionConfirm').onclick=async()=>{try{await request('retry',{taskId:correcting,sourceUrl:$('#bw8CorrectionUrl').value.trim()});correction.close();await poll();}catch(e){toast(e.message);}};
 function tasks(status){return snapshot?.tasks.filter(t=>t.status===status)||[];}
 function head(){return playing||tasks('playing')[0]||tasks('ready')[0];}
 const manualLivePlay=$('#bw7LivePlay').onclick,oldDoPlay=doPlay;
 doPlay=async function(){if(window.bwQueueActivePlaying){toast('队列视频播放中，请等待结束');return;}if(!window.bw817Fallback&&tasks('ready').length)return playNext();return oldDoPlay();};
 $('#bw7LivePlay').onclick=()=>!window.bw817Fallback&&tasks('ready').length?playNext():manualLivePlay();
 $('#bw8NewStream').onclick=async()=>{try{await request('config',{action:'new-stream'});$('#clearProfile').click();restorePreview();await poll();toast('当前面板已清零；旧任务保留在设置的历史记录中');}catch(e){toast(e.message);}};
 $('#bw815HistoryRefresh').onclick=async()=>{try{const h=await request('history',{}),list=$('#bw815History');list.replaceChildren();for(const t of h.tasks){const row=document.createElement('div');row.className='bw8-task';const title=document.createElement('small');title.textContent=(t.nickname||t.giftNickname||'未识别')+' · '+(names[t.status]||'已归档')+' · '+t.id.slice(0,8)+(t.templateName?' · '+t.templateName:'');const b=document.createElement('button');b.textContent=t.status==='ready'?'恢复到待播队列':'恢复并重新读取';b.onclick=()=>request('restore',{taskId:t.id}).then(async()=>{await poll();$('#bw815HistoryRefresh').click();toast('任务已恢复到当前场次');}).catch(e=>toast(e.message));row.append(title,b);list.append(row);}if(!h.tasks.length)list.textContent='没有未完成的历史任务';}catch(e){toast(e.message);}};
 $('#bw8Enabled').onchange=async()=>{try{await request('config',{enabled:$('#bw8Enabled').checked});await poll();}catch(e){toast(e.message);}};
 window.bwQueueRefreshLive=function(){if(!snapshot)return;const t=head();$('#bw7Name').textContent=t?.nickname||'等待送礼任务';window.bw71Avatar($('#bw7Avatar'),t?.avatarDataUrl||playing?.profile?.avatarDataUrl||'');$('#bw7Identity').textContent=t?'任务 '+t.id.slice(0,8)+' · 账号已确认':'尚无可播放任务';$('#bw711Template').textContent=t?.templateName?'本次模板：'+t.templateName:'';count.textContent='待播 '+tasks('ready').length+' · 处理中 '+snapshot.tasks.filter(x=>['pending','resolving','verified','composing'].includes(x.status)).length+' · 异常 '+tasks('failed').length;
  const message=playing?'正在播放：'+playing.nickname:tasks('ready').length?'已就绪，请核对头像和昵称后播放':tasks('composing').length?'FFmpeg 正在合成视频…':tasks('resolving').length?'正在读取并验证送礼用户…':snapshot.enabled?(snapshot.edgeConnected?'正在监听礼物，请保持明细展开':'等待 Edge 直播平台连接'):'自动监听已关闭';$('#bw7LiveStatus').textContent=message;$('#bw7LiveStatus').className='bw7-live-status '+(!t?'warn':'');$('#bw7LivePlay').disabled=!tasks('ready').length||!!playing||tasks('playing').length>0||playBusy||!pv.paused;$('#bw7LivePlay').textContent=playing?'播放中…':'立即播放';refreshPlay();if(t)poster(t);else if(posterId!==':empty'){posterId=':empty';++posterGeneration;previewPlaceholder('合成完成后显示核对画面');}};
 function refreshPlay(){const queueReady=!window.bw817Fallback&&tasks('ready').length>0,manualReady=window.bw7?.state().ready,blocked=!!playing||tasks('playing').length>0||playBusy||!pv.paused||state.composing;for(const id of ['playBtn','bw7LivePlay'])$('#'+id).classList.toggle('bw815-ready',!blocked&&(queueReady||manualReady));if(queueReady)$('#playBtn').disabled=blocked;}
 function restorePreview(time=0){if(state.videoSrc){restoreOriginal(time);return;}pv.pause();pv.removeAttribute('src');pv.load();state.playingComposed=false;sceneCtx.clearRect(0,0,1920,1080);}
 function previewPlaceholder(text){const canvas=$('#bw7Poster'),ctx=canvas.getContext('2d');delete canvas.dataset.bwQueuePoster;ctx.fillStyle='#030c10';ctx.fillRect(0,0,640,360);ctx.fillStyle='#90b9c3';ctx.font='18px Microsoft YaHei';ctx.textAlign='center';ctx.fillText(text,320,180);}
 async function poster(t){if(posterId===t.id)return;posterId=t.id;previewPlaceholder('正在读取待播画面…');const generation=++posterGeneration,v=document.createElement('video');v.crossOrigin='anonymous';v.muted=true;v.preload='metadata';v.src=API+'video?taskId='+t.id;
  try{await new Promise((r,j)=>{const timer=setTimeout(()=>j(Error('超时')),12000);v.onloadedmetadata=()=>{clearTimeout(timer);r();};v.onerror=()=>{clearTimeout(timer);j(Error('视频预览失败'));};});await new Promise((r,j)=>{const timer=setTimeout(()=>j(Error('超时')),12000);v.onseeked=()=>{clearTimeout(timer);r();};v.currentTime=Math.max(.001,v.duration-.15);});if(generation===posterGeneration){$('#bw7Poster').getContext('2d').drawImage(v,0,0,640,360);$('#bw7Poster').dataset.bwQueuePoster=t.id;}}catch{posterId='';}finally{v.removeAttribute('src');v.load();}}
 async function playNext(id=''){if(window.bwAlpha?.mode()==='alpha'&&!window.bwAlpha.connected()){toast('请先点击“打开直播输出窗口”；任务仍保留待播');return;}if(playBusy||playing||tasks('playing').length||!pv.paused||state.composing)return;playBusy=true;let task,oldEnd=pv.onended,oldError=pv.onerror;
  try{const reply=await request('play',{taskId:id});task=reply.task;playing={...task,nickname:task.profile.nickname,avatarDataUrl:task.profile.avatarDataUrl};window.bwQueueActivePlaying=true;sessionStorage.setItem('bw8Playback',JSON.stringify({taskId:task.id,playToken:task.playToken,completed:false}));
   const manualTime=pv.currentTime||0;pv.pause();pv.src=API+'video?taskId='+task.id;state.playingComposed=true;state.nativeClockSeq++;pv.load();await waitMeta();pv.currentTime=0;if(!state.nativeOutputActive)throw Error('请先点击“打开直播输出窗口”');if(!state.nativeOutputActive)throw Error('直播输出窗口未打开');
   const finish=async completed=>{if(!playing||playing.id!==task.id)return;window.bwQueueStop=null;pv.onended=oldEnd;pv.onerror=oldError;pv.pause();const ending={taskId:task.id,playToken:task.playToken,completed};sessionStorage.setItem('bw8Playback',JSON.stringify(ending));try{await request('end',ending);sessionStorage.removeItem('bw8Playback');}catch(e){toast('播放状态保存失败：'+e.message);}playing=null;window.bwQueueActivePlaying=false;restorePreview(manualTime);posterId='';await poll();};window.bwQueueStop=()=>finish(false);pv.onended=()=>finish(true);pv.onerror=()=>finish(false);await pv.play();sendNativeControl();startNativeFramePump();await poll();
  }catch(e){pv.onended=oldEnd;pv.onerror=oldError;if(task)await request('end',{taskId:task.id,playToken:task.playToken,completed:false}).then(()=>sessionStorage.removeItem('bw8Playback')).catch(()=>{});playing=null;window.bwQueueActivePlaying=false;restorePreview();toast('未开始播放：'+e.message);}finally{playBusy=false;window.bwQueueRefreshLive();}
 }
 function draw(){window.bwQueueOwnsLive=!window.bw817Fallback&&!!snapshot&&(snapshot.enabled||snapshot.tasks.some(t=>t.status!=='failed'));window.bwQueueWorking=renderBusy||tasks('composing').length>0||tasks('resolving').length>0;$('#bw8Enabled').checked=snapshot.enabled;$('#bw8Info').textContent=(snapshot.edgeConnected?snapshot.edgeState:'Edge 礼物页面未连接')+'\n身份：'+(tasks('resolving').length?'验证中':'等待任务')+' · 合成：'+(tasks('composing').length?'处理中':!templateIndex().length?'请先保存至少一个完整模板':'空闲')+(snapshot.capacity?'':'\n待播缓存已满，播放后继续制片');const s=snapshot.statistics;$('#bw8Stats').textContent='已收 '+s.received+' · 待播 '+tasks('ready').length+' · 完成 '+s.completed+' · 异常 '+tasks('failed').length+' · 捕获警告 '+s.warnings;$('#bw8Notice').textContent=snapshot.persistenceError||snapshot.notices.at(-1)||'';refreshPlay();
  const list=$('#bw8List');list.replaceChildren();for(const t of snapshot.tasks.slice(0,100)){const row=document.createElement('div');row.className='bw8-task';const title=document.createElement('strong');title.textContent=(t.nickname||t.giftNickname||'未识别用户')+' · '+names[t.status];const info=document.createElement('small');info.textContent=t.id.slice(0,8)+' · '+(t.gift||'礼物')+(t.corrected?' · 人工纠正':'')+(t.templateName?' · '+t.templateName:'');row.append(title,info);if(t.error){const e=document.createElement('small');e.className='bw8-error';e.textContent=t.error;row.append(e);}if(t.status==='composing'){const progress=document.createElement('small'),p=t.renderProgress||{};progress.textContent=(p.stage||'准备素材')+(p.duration&&p.frame>=0?' · '+Math.min(100,Math.floor(p.frame/(p.duration*60)*100))+'%':'')+(p.elapsedSeconds?' · '+p.elapsedSeconds+'秒':'');row.append(progress);}if(['pending','resolving','verified','composing'].includes(t.status)){const stop=document.createElement('button');stop.textContent='停止任务';stop.onclick=()=>request('cancel-task',{taskId:t.id}).then(poll).catch(e=>toast(e.message));row.append(stop);}if(t.status==='failed'){for(const correct of [false,true]){const b=document.createElement('button');b.textContent=correct?'核对身份':'重试';b.onclick=async()=>{if(correct){correcting=t.id;$('#bw8CorrectionInfo').textContent='原记录：'+t.giftNickname+' · '+t.gift+'\n'+t.error;$('#bw8CorrectionUrl').value=t.sourceUrl||'';correction.showModal();}else try{await request('retry',{taskId:t.id});poll();}catch(e){toast(e.message);}};row.append(b);}}if(t.status==='failed'){const again=document.createElement('button');again.textContent='重新选模板';again.onclick=()=>request('retry',{taskId:t.id,resetTemplate:true}).then(poll).catch(e=>toast(e.message));const archive=document.createElement('button');archive.textContent='归档异常';archive.onclick=()=>request('archive',{taskId:t.id}).then(poll).catch(e=>toast(e.message));row.append(again,archive);}list.append(row);}if(snapshot.tasks.length>100){const note=document.createElement('small');note.textContent='显示前 100 条，共 '+snapshot.tasks.length+' 条任务；先播放或处理前面的任务。';list.append(note);}if((window.bwQueueOwnsLive&&!window.bw817Fallback))window.bwQueueRefreshLive();}
 async function makeWorker(){if(worker?.isConnected&&worker.contentWindow?.bwQueueRender&&workerUses<6)return;worker?.remove();worker=null;workerUses=0;if(!workerHtml){workerHtml=await (await fetch('/')).text();const bootstrap="sync=function(){};poll=function(){};uiHeartbeat=function(){};pollGlobalCommand=function(){};saveWindowGeometry=function(){};loadHotkeys=function(){};renderSceneFrame=function(){};if(bc)bc.close();";workerHtml=workerHtml.replace('<script>','<script>window.BW_QUEUE_WORKER=true;').replace('startup();',bootstrap+'window.bwStartupReady=startup();');if(!workerHtml.includes('bwStartupReady'))throw Error('基线启动代码不匹配，未运行制片器');}
  workerHtml=workerHtml.replace('setInterval(poll,800);poll();','').replace('setInterval(uiHeartbeat,1200);uiHeartbeat();','').replace('setInterval(pollGlobalCommand,60);pollGlobalCommand();','').replace(/window\.addEventListener\('beforeunload',[^\n]+\);/g,'');
  worker=document.createElement('iframe');worker.setAttribute('aria-hidden','true');worker.style.cssText='position:fixed;left:-30000px;top:0;width:1920px;height:1080px;pointer-events:none;border:0';const ready=new Promise((r,j)=>{const timer=setTimeout(()=>j(Error('隔离制片器加载超时')),20000);worker.onload=()=>{if(!worker.contentWindow.bwQueueRender)return;clearTimeout(timer);r();};});worker.srcdoc=workerHtml;document.body.append(worker);await ready;if(!worker.contentWindow.bwQueueRender)throw Error('隔离制片器未就绪');}
 async function produce(){if(window.bw817Fallback||window.bw817Switching||renderBusy||state.composing||!templateIndex().length)return;renderBusy=true;let task;
  try{const reply=await request('render-claim',{owner});task=reply.task;if(!task)return;workerTouched=Date.now();await makeWorker();let prepareTimer;const output=await Promise.race([worker.contentWindow.bwQueueRender(task),new Promise((r,j)=>prepareTimer=setTimeout(()=>j(Error('模板准备超过45秒；请检查素材完整性')),45000))]).finally(()=>clearTimeout(prepareTimer));await request('template',{taskId:task.id,lease:task.lease,templateId:output.templateId,templateName:output.templateName});
   for(const kind of ['video','profile','deco']){if(!output[kind])continue;await window.bw71.upload(API+'upload/'+kind,output[kind],{'X-BW-Task':task.id,'X-BW-Lease':task.lease});}
   await request('compose',{taskId:task.id,lease:task.lease,...output.meta});workerUses++;
  }catch(e){worker?.remove();worker=null;if(task)await request('render-fail',{taskId:task.id,lease:task.lease,error:e.message}).catch(()=>{});else $('#bw8Notice').textContent=e.message;}
  finally{renderBusy=false;}
 }
 const logButtons=document.createElement('div');logButtons.style.cssText='display:flex;gap:6px;flex-wrap:wrap;margin-top:6px';
 for(const [text,action] of [['导出旧失败日志','export-failure-logs'],['打开日志文件夹','failure-log-folder']]){const b=document.createElement('button');b.textContent=text;b.onclick=()=>request(action,{}).then(r=>{if(action==='export-failure-logs')toast('已保存 '+r.count+' 份旧任务日志到桌面；旧记录没有页面诊断。');}).catch(e=>toast(e.message));logButtons.append(b);}
 const logState=document.createElement('small');logState.style.cssText='display:block;overflow-wrap:anywhere';logButtons.append(logState);queueSettings.append(logButtons);
 async function poll(){if(worker&&!renderBusy&&Date.now()-workerTouched>120000){worker.remove();worker=null;workerUses=0;}if(pollBusy)return;pollBusy=true;try{snapshot=await request('state?details=1');if(!playing){let interrupted;try{interrupted=JSON.parse(sessionStorage.getItem('bw8Playback')||'null');}catch{}if(interrupted){const t=snapshot.tasks.find(t=>t.id===interrupted.taskId);if(t?.status==='playing'){await request('end',interrupted);snapshot=await request('state?details=1');}sessionStorage.removeItem('bw8Playback');}}draw();logState.textContent=snapshot.failureLogs?.error?'桌面日志写入失败：'+snapshot.failureLogs.error:snapshot.failureLogs?.lastPath?'本次失败日志已保存到本软件目录内的读取失败日志':'失败时自动记录到本软件目录内的读取失败日志';produce();}catch(e){$('#bw8Info').textContent='任务服务异常：'+e.message;}finally{pollBusy=false;}}
 window.bw8={poll,playNext,state:()=>snapshot,produce};poll();setInterval(poll,800);
})();




/* V8.1.7 transparent-output release. No colour key. Ordinary video stays opaque. */
(()=>{
 'use strict';
 if(window.BW_QUEUE_WORKER)return;
 const endpoint='http://127.0.0.1:38656',original={open:openNativeOutput,control:sendNativeControl,frame:scheduleNativeFrame,socket:connectNativeFrameSocket};
 const canvas=document.createElement('canvas');canvas.width=1920;canvas.height=1080;
 const ctx=canvas.getContext('2d',{alpha:true,willReadFrequently:true});let visible=false,alpha=true,opening=null,modeEpoch=0,lastError='',unloading=false,userOpened=false;
 const connected=()=>state.nativeOutputActive&&state.nativeWS?.readyState===WebSocket.OPEN;
 const encoder=new TextEncoder();
 function blank(){if(!alpha)return;visible=false;sendNativeControl();}
 function control(){if(!state.nativeOutputActive||state.nativeWS?.readyState!==WebSocket.OPEN)return;const b=encoder.encode(JSON.stringify({currentMs:(pv.currentTime||0)*1000,playing:!pv.paused&&!pv.ended,profileEnabled:false,decoEnabled:false,clockSeq:state.nativeClockSeq,alphaMode:visible?'video':'idle'}));state.nativeWS.send(new Blob([new Uint8Array([179]),b]));}
 function frame(force=false){if(!state.nativeOutputActive||state.nativeWS?.readyState!==WebSocket.OPEN||state.nativeCaptureBusy)return;if(!visible){control();return;}if(state.nativeWS.bufferedAmount>4194304&&!force)return;state.nativeCaptureBusy=true;const socket=state.nativeWS;(()=>{try{if(!visible||!alpha||socket!==state.nativeWS||socket.readyState!==WebSocket.OPEN){if(alpha)control();return;}if(pv.readyState<2||!pv.videoWidth)return;ctx.clearRect(0,0,1920,1080);ctx.fillStyle='#000';ctx.fillRect(0,0,1920,1080);coverDraw(ctx,pv,0,0,1920,1080);const im=ctx.getImageData(0,0,1920,1080);socket.send(im.data.buffer);control();}catch(e){visible=false;try{control();socket.close();}catch(_){}state.nativeOutputActive=false;toast('透明输出中断：'+e.message);}finally{state.nativeCaptureBusy=false;}})();}
 function open(notify=true){
  if(!alpha||unloading||!userOpened)return Promise.resolve(false);
  if(connected())return Promise.resolve(true);
  if(opening)return opening;
  const epoch=modeEpoch;lastError='';
  const attempt=(async()=>{try{
   const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),3000);let d;
   try{const r=await fetch(endpoint+'/open',{cache:'no-store',signal:abort.signal});d=await r.json();}finally{clearTimeout(timer);}
   if(!d.ok)throw Error(d.error||'组件未就绪');if(!alpha||unloading||epoch!==modeEpoch)return false;
   const w=await socket('ws://127.0.0.1:38656/frame');
   if(!alpha||unloading||epoch!==modeEpoch){w.close();return false;}
   state.nativeOutputActive=true;visible=!pv.paused&&!pv.ended;control();startNativeFramePump();frame(true);
   if(notify)toast('透明直播输出已连接；闲置时透明');return true;
  }catch(e){if(epoch===modeEpoch){state.nativeOutputActive=false;lastError=e.message;if(notify)toast('透明输出未连接：'+e.message+'；请点击打开直播输出窗口重试');}return false;}})();
  opening=attempt;attempt.finally(()=>{if(opening===attempt)opening=null;});return attempt;
 }
 function socket(url){return new Promise((resolve,reject)=>{if(state.nativeWS?.readyState===WebSocket.OPEN){resolve(state.nativeWS);return;}const w=new WebSocket(url);let opened=false;w.binaryType='arraybuffer';state.nativeWS=w;const timer=setTimeout(()=>{w.close();reject(Error('帧通道超时'));},3000);w.onopen=()=>{opened=true;clearTimeout(timer);resolve(w);};w.onerror=()=>{clearTimeout(timer);reject(Error('帧通道连接失败'));};w.onclose=()=>{clearTimeout(timer);if(!opened)reject(Error('帧通道已关闭'));if(state.nativeWS===w){state.nativeWS=null;state.nativeOutputActive=false;stopNativeFramePump();}};});}
 function bind(){openNativeOutput=alpha?open:original.open;sendNativeControl=alpha?control:original.control;scheduleNativeFrame=alpha?frame:original.frame;connectNativeFrameSocket=alpha?socket:original.socket;$('#openOutputBtn').onclick=toggleOutput;if($('#bw71LiveOutput'))$('#bw71LiveOutput').onclick=toggleOutput;}
 bind();
 
 pv.addEventListener('play',async()=>{if(!alpha)return;if(!userOpened)return;visible=true;if(!connected()&&!await open(false))return;if(!alpha||pv.paused||pv.ended)return;control();startNativeFramePump();frame(true);});
 for(const name of ['ended','emptied','error'])pv.addEventListener(name,blank);
 pv.addEventListener('pause',()=>{if(alpha&&visible){control();frame(true);}});
 window.addEventListener('beforeunload',()=>{blank();unloading=true;modeEpoch++;try{if(alpha)state.nativeWS?.close();}catch(_){}});
 setInterval(()=>{if(alpha)control();},500);
 async function stopPlayback(){blank();if(window.bwQueueStop)await window.bwQueueStop();else{pv.pause();if(state.playingComposed)restoreOriginal();}blank();}
 function makeStop(id){const b=document.createElement('button');b.id=id;b.className='secondary';b.textContent='停止播放';b.title='结束当前播放；透明输出模式下立即恢复透明，队列任务仍可重播';b.onclick=()=>stopPlayback().catch(e=>toast('停止失败：'+e.message));return b;}
 function makeStatus(id){const e=document.createElement('div');e.id=id;e.setAttribute('aria-live','polite');e.style.cssText='font-size:12px;margin-top:7px;line-height:1.6';return e;}
 const strip=$('#playBtn').closest('.output-grid');strip.id='bwAlphaOutput';$('#playBtn').before(makeStop('bwAlphaStop'));
 const layout=document.createElement('style');layout.textContent='#bwAlphaOutput{grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}#bwAlphaOutput>#composeBtn,#bwAlphaOutput>#playBtn,#bwAlphaOutput>#bwAlphaStop{min-width:0;padding:6px 4px;font-size:10.5px;white-space:nowrap;min-height:34px}#bwAlphaOutput>.hotkey-btn{gap:2px}#bwAlphaOutput .hotkey-badge{font-size:7.5px;padding:1px 2px}#bwAlphaLiveActions{display:grid;grid-template-columns:1fr 1fr;gap:8px;flex-shrink:0}#bwAlphaLiveActions>button{width:100%;min-height:46px;margin:0}';document.head.append(layout);
 const status=makeStatus('bwAlphaStatus');strip.after(status);
 const liveActions=document.createElement('div');liveActions.id='bwAlphaLiveActions';$('#bw7LivePlay').before(liveActions);liveActions.append(makeStop('bwAlphaLiveStop'),$('#bw7LivePlay'));
 const liveStatus=makeStatus('bwAlphaLiveStatus');$('#bw71LiveOutput').after(liveStatus);
 const options=document.createElement('details');options.id='bwAlphaSettings';options.style.cssText='margin:12px 0;padding:10px;border:1px solid #28515c;border-radius:8px';options.innerHTML='<summary>直播输出设置</summary><label class="bw71-field" for="bwAlphaMode">输出方式<select id="bwAlphaMode"><option value="alpha">透明输出（默认）</option><option value="legacy">原版输出（兼容）</option></select></label><p class="bw71-note">透明输出会在视频结束或停止后自动恢复透明。切换输出方式前请先停止播放；原版输出使用另一采集窗口，需要在直播伴侣重新选择。每次启动默认使用透明输出。</p><div id="bwAlphaDiagnostics" style="font-size:12px;line-height:1.6"></div>';
 $('#bw71Dialog').querySelector('.bw71-field').before(options);
 const guideLabel=document.createElement('label');guideLabel.className='bw71-note';guideLabel.innerHTML='<input type="checkbox" id="bw817Guide" checked> 显示桌面拖动虚线框（直播采集排除）';options.querySelector('p').after(guideLabel);
 const guide=$('#bw817Guide');guide.checked=localStorage.getItem('bw817Guide')!=='0';guide.onchange=async()=>{localStorage.setItem('bw817Guide',guide.checked?'1':'0');if(alpha&&userOpened)try{await window.bw71.api('/api/app/alpha-guide',{show:guide.checked});}catch(e){toast(e.message);}};
 const mode=$('#bwAlphaMode');mode.onchange=async()=>{const desired=mode.value==='alpha';if(desired===alpha)return;if(!pv.paused||state.composing||window.bwQueueActivePlaying){mode.value=alpha?'alpha':'legacy';toast('请先停止播放并等待合成完成，再切换输出方式');return;}mode.disabled=true;try{blank();modeEpoch++;opening=null;stopNativeFramePump();const previous=state.nativeWS;try{if(previous){previous.onclose=null;previous.close();}}catch(_){}state.nativeWS=null;state.nativeOutputActive=false;if(alpha)await window.bw71.api('/api/app/alpha-close',{});alpha=desired;userOpened=false;visible=false;bind();updateStatus();toast(alpha?'已切换透明输出':'已切换原版输出，请在直播伴侣重新选择原版窗口');}finally{mode.disabled=false;}};
 async function toggleOutput(){
  if(opening)return;if(userOpened&&connected()){
   if(!pv.paused){toast('请先停止播放，再关闭输出窗口');return;}
   blank();userOpened=false;modeEpoch++;stopNativeFramePump();state.nativeWS?.close();state.nativeWS=null;state.nativeOutputActive=false;
   if(alpha)await window.bw71.api('/api/app/alpha-close',{});updateStatus();return;
  }
  try{if(alpha){await window.bw71.api('/api/app/alpha-open',{});userOpened=true;if(!await open())throw Error(lastError||'帧通道连接失败');await window.bw71.api('/api/app/alpha-guide',{show:guide.checked});}else{userOpened=true;await original.open();}updateStatus();}catch(e){toast('输出打开失败：'+e.message);}
 }
 function statusText(text,color){for(const e of [status,liveStatus]){e.textContent=text;e.style.color=color;}}
 let reading=false;async function updateStatus(){if(reading||unloading)return;for(const id of ['openOutputBtn','bw71LiveOutput'])$('#'+id).textContent=userOpened&&connected()?'关闭直播输出窗口':'打开直播输出窗口';reading=true;try{
  if(!alpha){statusText('输出状态：原版输出','#a5bbc1');$('#bwAlphaDiagnostics').textContent='原版兼容输出已启用；重新选择原版窗口素材。';return;}
  if(!connected()){const t=opening?'输出状态：正在连接…':'输出状态：'+(userOpened?'连接中断，请点击重新打开':'窗口未打开')+(lastError?' · '+lastError:'');statusText(t,'#ffd35a');$('#bwAlphaDiagnostics').textContent=t;return;}
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),1500);let h;try{h=await fetch(endpoint+'/health',{cache:'no-store',signal:abort.signal}).then(r=>r.json());}finally{clearTimeout(timer);}
  if(!alpha||!connected())return;const t='输出状态：已连接 · '+(h.mode==='video'?(pv.paused?'已暂停':'播放中'):'透明待机');statusText(t,'#36d9ba');$('#bwAlphaDiagnostics').textContent=t+' · 已显示 '+h.frames+' 帧'+(h.guideError?' · '+h.guideError:'')+(h.error?' · '+h.error:'');
 }catch(e){statusText('输出状态：组件未响应，请重新启动软件','#ffd35a');}finally{reading=false;}}
 updateStatus();setInterval(updateStatus,1000);
 document.title='美丽武器 V8.1.7 透明输出版';
 document.querySelector('.brand span').textContent='美丽武器 V8.1.7 · 透明输出版';
 window.bwAlpha={version:'1.7',userOpened:()=>userOpened,toggle:toggleOutput,visible:()=>visible,mode:()=>alpha?'alpha':'legacy',connected,blank,open,canvas,stop:stopPlayback};
 if(new URLSearchParams(location.search).get('alpha-self-test')==='1'){const s=document.createElement('script');s.src=endpoint+'/harness.js';document.body.append(s);}
})();

/* Preserve user assets; explicitly choose between queue and homepage backup. */
(()=>{
 'use strict';if(window.BW_QUEUE_WORKER)return;
 const bridge='http://127.0.0.1:38560';let applying=false,recoveryDone=false;
 const note=document.createElement('small');note.id='bw817Recovery';note.style.cssText='display:block;margin:6px 0;color:#a6ccd0;overflow-wrap:anywhere';$('#bw81Templates').append(note);
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 async function recovery(){if(applying||recoveryDone)return;applying=true;try{
  const r=await fetch(bridge+'/api/app/recovery-state',{cache:'no-store'}).then(r=>r.json());note.textContent=r.message;
  if(r.phase==='complete'){recoveryDone=true;return;}if(r.phase!=='ready')return;
  const list=templateIndex();let restored=0;
  for(const raw of r.manifest.templates){const existing=list.find(t=>t.id===raw.id),t=existing||structuredClone(raw);
   for(const k of ['video','font','deco']){const a=raw.recoveryAssets[k];if(!a||await idbGet('tpl:'+raw.id+':'+k))continue;
    const response=await fetch(bridge+'/api/app/recovery-asset?key='+a.sha256,{cache:'no-store'});if(!response.ok)throw Error('旧模板素材读取失败');const bytes=await response.arrayBuffer();const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');if(hash!==a.sha256||bytes.byteLength!==a.size)throw Error('旧模板素材校验失败');
    await idbPut('tpl:'+raw.id+':'+k,new File([bytes],a.name||raw.assets?.[k]?.name||k,{type:a.type||raw.assets?.[k]?.type||''}));
   }
   if(!existing){delete t.recoveryAssets;if(list.some(x=>x.name===t.name))t.name+='（旧版恢复）';list.push(t);restored++;saveTemplateIndex(list);}
  }
  refreshTemplates($('#templateSelect').value);await window.bw71.api('/api/app/recovery-applied',{count:restored});note.textContent='已恢复 '+restored+' 套旧模板，现有模板保留';recoveryDone=true;
 }catch(e){note.textContent='恢复未完成：'+e.message+'；原数据保留，稍后重试';}finally{applying=false;}}
 setInterval(recovery,2200);setTimeout(recovery,1200);
 const box=document.createElement('div');box.style.cssText='margin:12px 0;padding:10px;border:1px solid #28515c;border-radius:8px';box.innerHTML='<strong>主页备用合成</strong><p class="bw71-note">自动队列识别失败时，启用此方案并手动打开送礼用户的抖音主页。网页助手读到完整头像和昵称后自动合成；核对后点击播放。备用方案会暂停队列，已有任务保留。</p><button id="bw817FallbackBtn" class="secondary">启用主页备用合成</button><small id="bw817FallbackStatus" style="display:block;margin-top:6px"></small>';
 $('#bwAlphaSettings').after(box);
 const quick=document.createElement('button');quick.id='bw817FallbackQuick';quick.className='secondary';quick.style.cssText='margin:6px 0';$('#bw7LiveStatus').after(quick);
 function label(){const text=window.bw817Fallback?'返回自动队列':'启用主页备用合成';$('#bw817FallbackBtn').textContent=quick.textContent=text;$('#bw817FallbackStatus').textContent=window.bw817Fallback?'备用方案已启用：手动打开用户主页即可读取并合成':'当前使用自动队列';}
 async function fallback(value,initial=false){if(state.composing||!pv.paused||window.bwQueueActivePlaying){toast('请先停止播放并等待合成完成');return false;}window.bw817Switching=true;
  try{await window.bw8.poll();const q=window.bw8.state();if(q.tasks.some(t=>['composing','resolving','playing'].includes(t.status))){toast('请等待当前任务处理结束后切换');return false;}
   if(value){if(!initial)localStorage.setItem('bw817QueueBeforeFallback',q.enabled?'1':'0');await window.bwQueueApi('config',{enabled:false});window.bw817Fallback=true;state.autoReceive=true;$('#autoReceive').checked=true;state.locked=false;$('#lockProfile').textContent='锁定当前用户';$('#bw7Auto').checked=true;$('#bw7Auto').dispatchEvent(new Event('change'));}
   else{window.bw817Fallback=false;await window.bwQueueApi('config',{enabled:localStorage.getItem('bw817QueueBeforeFallback')==='1'});}
   localStorage.setItem('bw817Fallback',value?'1':'0');await window.bw8.poll();await window.bw7Poll();label();toast(value?'已启用主页备用合成；请手动打开送礼用户主页':'已返回自动队列');return true;
  }catch(e){toast('切换失败：'+e.message);return false;}finally{window.bw817Switching=false;label();}}
 $('#bw817FallbackBtn').onclick=quick.onclick=()=>fallback(!window.bw817Fallback);label();
 if(window.bw817Fallback)setTimeout(()=>fallback(true,true),1100);
 const enabled=$('#bw8Enabled'),prior=enabled.onchange;enabled.onchange=async()=>{if(window.bw817Fallback){enabled.checked=false;toast('请先返回自动队列，再开启自动监听');return;}return prior();};
 const ontime=pv.ontimeupdate;pv.ontimeupdate=function(...args){ontime?.apply(this,args);if(state.composing)$('#composeBtn').querySelector('span').textContent='合成中...';};
 window.bw817={fallback,recovery,status:()=>({fallback:window.bw817Fallback,recoveryDone})};
})();
